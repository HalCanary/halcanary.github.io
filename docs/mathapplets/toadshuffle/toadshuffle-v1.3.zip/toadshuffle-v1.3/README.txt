TOAD Shuffler Applet
Copyright (C) 2001-2004 Hal Canary, Univerity of Wisconsin-Madison.
hal@ups.physics.wisc.edu

A description of the algorithm can be found in the file index.html

Licence Information:

        This program is free software; you can redistribute it and/or
        modify it under the terms of version 2 of the GNU General
        Public License as published by the Free Software Foundation.

        A copy of the liscence was distributed in the file LICENCE.txt

        This program is distributed in the hope that it will be
        useful, but WITHOUT ANY WARRANTY; without even the implied
        warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
        PURPOSE.  See the GNU General Public License for more details.

Run the program from the command line by typing

	appletviewer index.html

or run the program in a java-enabled browser by opening the file
index.html.

Source lives in the src/ directory.  Run 'make' from that directory to
recompile.

Changelog:

	v1.0 (Spring 2002)
	  --> Initial work
	
	v1.1 (September 2002)
	  --> Increase speed of applet.
	  --> Redesigned index.html
	  --> Use of .jar file for quicker download.

	v1.2 (Januart 2004)
	  --> new geometry.
	  --> better use of window.
	  --> fix broken help.

	v1.3 (March 2004)
	  --> Improve interface.

