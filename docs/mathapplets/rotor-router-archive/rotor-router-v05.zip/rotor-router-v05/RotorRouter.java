/* 
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
import java.awt.*;

/** Mathematical Model of the Rotor Router Object **/
public class RotorRouter extends MathSystem {
    static int defaultMaxSize = 2048;
    public boolean allArrows;
    public int maxSize ;
    public int aSize;
    char [] [] sandpile ;
    int middle;
    int posR;
    int posC;
    
    public int [] recentR ;
    public int [] recentC ;

    public int n; //iteration
    int subiteration;
    public boolean badness;
    boolean done;
    boolean filled;

    int lastR;
    int lastC;

    Color up;
    Color down;
    Color right;
    Color left;
	
    /** Creates a new empty RotorRouter **/
    public RotorRouter() {
	maxSize = defaultMaxSize;
	reset();
    } 
    public RotorRouter(int n) {
	maxSize = n;
	reset();
    } 

    public void reset() {
	filled = false;
	allArrows = true;
	n = 0;
	badness = false;
	done = true;
	aSize = 7;
	sandpile = new char [aSize][aSize];
	for(int r = 0 ; r < aSize ; r++) {
	    for(int c = 0 ; c < aSize ; c++) {
		sandpile[r][c] = ' ' ;
	    }
	}
	middle = 3;
	lastR=-1;
	lastC=-1; //just in case.
	recentC = new int [aSize] ;
	recentR = new int [aSize] ;
	up     = new Color(255,63,63); 
	down   = Color.green;
	right  = new Color(127,127,255); 
	left   = Color.yellow;
    }

    public void subiterate(int numsub) {
	if (done) { // new iteration
	    n++;
	    subiteration = 0;
	    posR = middle;
	    posC = middle;
	    done = false;
	}
	for(int bleg = 0; bleg < numsub; bleg++) {
	    if ((! done) && (! badness) && (! filled)) {
		recentR [subiteration] = posR;
		recentC [subiteration] = posC;
		subiteration++;
		if (subiteration == recentR.length) {
		    int oldsize = recentR.length;
		    int tempR [] = recentR;
		    int tempC [] = recentC;
		    recentC = new int [oldsize * 2] ;
		    recentR = new int [oldsize * 2] ;
		    for(int i = 0; i < oldsize; i++) {
			recentR [i] = tempR [i];
			recentC [i] = tempC [i];
		    }
		}
		//System.out.println("R,C = "+posR+","+posC);
		if (sandpile[posR][posC] == ' ') {
		    sandpile[posR][posC] = 'l';
		    recentR [subiteration] = -1;  // This indicates that 
		    recentC [subiteration] = -1;  //     we are done! 
		    lastR = posR;
		    lastC = posC;
		    done = true;
		} else if (sandpile[posR][posC] == 'u') {
		    sandpile[posR][posC] = 'r';
		    posC++;
		    if (posC == aSize) { filled = !resizeArray(); }
		} else if (sandpile[posR][posC] == 'r') {
		    sandpile[posR][posC] = 'd';
		    posR++;
		    if (posR == aSize) { filled = !resizeArray(); }
		} else if (sandpile[posR][posC] == 'd') {
		    sandpile[posR][posC] = 'l';
		    posC--;
		    if (posC < 0) { filled = !resizeArray(); }
		} else if (sandpile[posR][posC] == 'l') {
		    sandpile[posR][posC] = 'u';
		    posR--;
		    if (posR < 0) { filled = !resizeArray(); }
		} else {
		    System.out.println("shouldn't happen! ");	
		}		
	    }
	}
	return;
    }
    public void iterate(int number) {
	int num;
	for(num = 0; (num < number) && (!filled); num++) {
	    if (done) {
		n++;
		subiteration = 0;
		posR = middle;
		posC = middle;
		done = false;
	    }
	    while ((! done) && (! badness) && (! filled)) {
		subiterate(1); 
	    }
	} 
	return;
    }
    /** return true if successfull. **/
    private boolean resizeArray() {
	//System.out.println("Resizing! \n");	
        int newArraySize = aSize * 2 + 1;
	if (newArraySize > maxSize) {
	    //do something here to stop this!!!!
	    badness = true;
	    return false;
	}
	int newMiddle = aSize; //(newArraySize - 1) / 2;  
	int shift = newMiddle - middle;
	char [] [] oldPile = sandpile;	
        sandpile = new char[newArraySize][newArraySize];
        for(int r = 0 ; r < newArraySize ; r++) {
            for(int c = 0 ; c < newArraySize ; c++) {
                sandpile[r][c] = ' ';
            }
        }
	//25% wasteful!  What to do? Worry about smething else!
        for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
                sandpile[r+shift][c+shift] = oldPile[r][c] ;
            }
        }
	oldPile = null;
	//garbage collect???
        middle = newMiddle;
	posR = posR + shift;
	posC = posC + shift;
	aSize = newArraySize;
	return true;
    }

    public void printArray() {
	System.out.print("Grain number ");
	System.out.println(n);
	for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
		System.out.print(sandpile[r][c]);
		System.out.print(' ');
	    }
	    System.out.print('\n');
	}
	System.out.print('\n');
    }

    public void draw(int sizeX, int sizeY, Graphics g){
	int square;
	if (sizeX < sizeY) { square = sizeX; }
	else { square = sizeY; }
	int block = square / aSize;
	g.clearRect(1,1,square,square) ;
	g.setColor(Color.white);
	g.fillRect(1,1,aSize * block,aSize * block) ;
	g.setColor(Color.black);
	g.drawRect(0,0,(aSize * block)+1,(aSize * block)+1) ;
        for (int r = 0 ; r < aSize ; r++) {
            for (int c = 0 ; c < aSize ; c++) {
		if (sandpile[r][c] == 'u') {
		    g.setColor(up);
		    g.fillRect((block * c) + 1, (block * r) + 1, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'u',block);}
		} else if (sandpile[r][c] == 'r') {
		    g.setColor(right);
		    g.fillRect((block * c) + 1, (block * r) + 1, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'r',block);}
		} else if (sandpile[r][c] == 'd') {
		    g.setColor(down);
		    g.fillRect((block * c) + 1, (block * r) + 1, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'d',block);}
		} else if (sandpile[r][c] == 'l') {
		    g.setColor(left);
		    g.fillRect((block * c) + 1, (block * r) + 1, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'l',block);}
		} 
	    }
	}
	if (block >= 5) {
	    if (allArrows) {
		if (lastR != -1) {
		    drawArrow(g,lastR,lastC,'X',block);
		}
	    } else {
		g.setColor(Color.black);
		for (int i = 0 ; i < subiteration ; i++) {
		    //if (recentR[i] == -1) {
		    //	i = recentR.length; //we are done.  Hack!
		    //} else {
			char dir = sandpile[recentR[i]][recentC[i]] ;
			if (i < recentR.length-1 ) {
			    if (recentR[i+1] == -1 )
				dir = 'X';
			}
			drawArrow(g,recentR[i],recentC[i],dir,block);
			//}
 		}
 	    }
	    if (done) {
		drawArrow(g,middle,middle,'C',block);
	    } else {
		drawArrow(g,posR,posC,'C',block);
	    }
	}
    }
    /**
       r,c row and column
     **/
    void drawArrow(Graphics g, int r, int c, char dir, int b) {
	int cX = 1 + (b*c) + (b/2);
	int cY = 1 + (b*r) + (b/2);
	g.setColor(Color.black);
	if (dir == 'u' || dir =='d') {
	    g.drawLine(cX, cY-(b/4), cX, cY+(b/4));
	    if (dir == 'u') {
		g.drawLine(cX, cY-(b/4), cX+(b/4), cY);
		g.drawLine(cX, cY-(b/4), cX-(b/4), cY);
	    } else {
		g.drawLine(cX, cY+(b/4), cX+(b/4), cY);
		g.drawLine(cX, cY+(b/4), cX-(b/4), cY);
	    }
	} else if (dir == 'r' || dir =='l') {
	    g.drawLine(cX-(b/4), cY, cX+(b/4), cY);
	    if (dir == 'r') {
		g.drawLine(cX+(b/4), cY, cX, cY+(b/4));
		g.drawLine(cX+(b/4), cY, cX, cY-(b/4));
	    } else {
		g.drawLine(cX-(b/4), cY, cX, cY+(b/4));
		g.drawLine(cX-(b/4), cY, cX, cY-(b/4));
	    }
	} else if (dir == 'X') {
 	    g.drawRect((b*c)+1,(b*r)+1,b-1,b-1);
 	}
	else if (dir == 'C') {
	    g.drawRect((b*c)+1,(b*r)+1,b-1,b-1);
	    if (b > 6) { 
		g.setColor(Color.white);
		g.drawRect((b*c)+2,(b*r)+2,b-3,b-3);
		if (b > 9) { 
		    g.setColor(Color.black);
		    g.drawRect((b*c)+3,(b*r)+3,b-5,b-5);
		}
	    }
	}
    }

    public static void main(String[] args) {
	RotorRouter r;
	r = new RotorRouter(550) ;
	//r.iterate(0);
	while (! r.badness) {
	    r.printArray();
	    try { 
		Thread.sleep(500);  //miliseconds;
	    } catch (InterruptedException e) { }
	    r.iterate(1);
	}
    }
}
