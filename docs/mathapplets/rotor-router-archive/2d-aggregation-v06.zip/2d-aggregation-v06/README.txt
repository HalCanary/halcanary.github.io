RotorRouter Applet
Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
hal@ups.physics.wisc.edu

A description of the algorithm can be found in the file index.html

Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

Instructions:  

	Run the program in a java-enabled browser by opening the file
	index.html.

	Or on a system with a Java SDK installed, enter:

		$ appletviewer index.html

	at the command line.

Version Information.
	v0.1 - Completed 2003-09-21 
		> All options are compiled in.
		> Proof of concept.

	v0.2 - Completed 2003-09-21 
		> Fixed a display bug. 
		> Show path of the last grain.
		> Slightly better look.

	v0.3 - Completed 2003-09-22
		> Keybindings to control the applet.	
		> Control Buttons for speed, pause, and reset.
		> No Flicker.
		> Pause Button.   (as well as [spacebar])
		> Speed Control.  (as well as +/-)
		> Restart Button. (as well as Ctrl+Shift+R)

	v0.4 - Completed 2003-09-24
		> Colors now pleasing to the eye.  Martha Stewart
		  would be proud.. 
		> The arrows are now separate from one another,
		> A mode that allows one to skip over lots of steps.

	v0.5 - In Progress
		> Slow down, show each move of the grain. "Step"
		> Skip Each Step = 0 by default.
		> Zoom Feature.

	Future Goals:
		- Showing the last two places along the boundary 
		- Slow down, show each move of the grain?
		- Better Layout.
		- Better choice of arraysize?
