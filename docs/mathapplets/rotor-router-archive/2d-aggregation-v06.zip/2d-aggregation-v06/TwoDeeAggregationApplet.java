/*
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/**
 * This class controlls most of the  RotorRouter Applet.  It uses the 
 * RotoRouter class.
 **/
public class TwoDeeAggregationApplet extends Applet 
    implements Runnable, MouseListener, KeyListener {
    
    public boolean pause;
    public boolean dead;
    public int sleep;

    int zoom;
    static int maxZoom = 2;   // mamimum zoom factor is 2^maxZoom;
    int canvasSize;
    
    public Panel leftPanel;
    public Image buffer;
    public Graphics gb;
    public Graphics agraph;
    public static int square = 512;

    public Thread t;
    public TwoDeeAggregation r;
    public Scrollbar speedSlider ;
    ScrollPane spane;
    //Canvas scrollCanvas;
    ICanvas sCanvas;

    int skipEach;
    
    Font bigfont;
    Font normalfont;

    CButton pauseButton;
    CButton fastButton;
    CButton slowButton;
    CButton restartButton;
    CButton jumpToButton;
    //CButton arrowButton;
    CButton jumpToButton2;
    CButton intervalLabel;
    CButton iterationLabel;
    CButton zoomInButton ;
    CButton zoomOutButton;
    CButton stepButton;
    CButton stageButton;

    SkipTo skipTo;

    /** Initialize **/
    public void init() {
	dead = false;
	pause = true;
	sleep = 400;
	zoom = 0;
	skipEach = 0;
	canvasSize = square ;//* (int)(java.lang.Math.pow(2,zoom));
	this.addMouseListener(this);
	this.addKeyListener(this);
	this.setBackground(Color.white);
	this.setBackground(new Color(230,230,230));
	//this.setForeground(Color.black);
	bigfont = new Font("SansSerif",Font.PLAIN,40);
	normalfont = new Font("SansSerif",Font.PLAIN,20);
	this.setFont(normalfont);
	r = new TwoDeeAggregation(square) ;
	FontMetrics m = this.getFontMetrics(normalfont);
	skipTo = new SkipTo(this,"Jump to stage: ");
	pauseButton = new CButton("Paused",25,20,true,m);
	fastButton = new CButton("Faster",25,20+40,true,m);
	slowButton = new CButton("Slower",150,20+40,true,m);
	intervalLabel = new CButton("Interval = "+sleep+"ms",25,20+80,false,m);
	iterationLabel = new CButton("Stage = 0",25,20+120,false,m);
	restartButton = new CButton("Restart",25,20+160,true,m);
	jumpToButton = new CButton("Jump To",25,20+200,true,m);
	//arrowButton = new CButton("All Arrows",25,20+240,true,m);
	jumpToButton2 = new CButton("Skip Stages = "+skipEach,
				    25,20+240,true,m);
	zoomInButton = new CButton("Zoom In",25,20+280,true,m);
	zoomOutButton = new CButton("Zoom Out",160,20+280,true,m);
	stageButton = new CButton("Stage",25,20+320,true,m);
	stepButton = new CButton("Step",25,20+3600,true,m);

	//ffers = new Image [maxZoom+1];
	// = new Graphics [maxZoom+1];
	buffer = createImage(canvasSize,canvasSize);
	gb = buffer.getGraphics();
	agraph = this.getGraphics();

	spane = new ScrollPane(ScrollPane.SCROLLBARS_ALWAYS);
	spane.setSize(square, square);
	spane.setBounds(400,2,square,square);
	//scrollCanvas = new Canvas();
	//scrollCanvas.setVisible(true);
	//spane.add(scrollCanvas);

	sCanvas = new ICanvas(square,square,buffer);
	spane.add(sCanvas);
	spane.setVisible(false);
	this.add(spane);
	//this.pack();
	this.setVisible(true);
	spane.getVAdjustable().setUnitIncrement(5);
	spane.getHAdjustable().setUnitIncrement(5);

	Thread t = new Thread(this);
	t.start();
	r.draw(canvasSize,canvasSize,gb);
	this.repaint();
    }

    /** unpause **/
    //public void start() { pause = false; pauseButton.changeText("Unpaused");}
    /** pause **/
    //public void stop() { pause = true; pauseButton.changeText("Paused");}

    /** Kill **/
    public void destroy() { 
	r = null;
	dead = true;
	try {
	    t.interrupt();
	} 
	catch (SecurityException ex) {} 
	catch (java.lang.NullPointerException ex) {}
	t = null;
    }

    /** when you make a thread**/
    public void run() {
 	while (!dead) {
	    if (!pause){
		if (skipEach > 0) {
		    r.iterate(skipEach);
		    if (gb != null) 
			r.draw(canvasSize,canvasSize,gb);
		    this.rotorPaint(this.getGraphics()); 
		} else {
		    step();
		}
	    }
	    try { 
		t.sleep(sleep); //miliseconds;
	    } catch (InterruptedException e) { }
	}
    }

    /** Skip to iteration  **/
    public void skip(int iteration) {
	pause = true;
	pauseButton.changeText("Paused");
	r.iterate(iteration - r.n);
	if (gb != null) {
	    r.draw(canvasSize,canvasSize,gb);
	}
	this.repaint();
    }
    public void skipEachStep(int i){
	skipEach = i;
	jumpToButton2.changeText("Skip Each Step = "+skipEach);
	//change
	this.repaint();
    }
    
    public void paint(java.awt.Graphics g) {
	Rectangle rect;
	String s;
	int x;
  	if (g != null) {
	    g.setColor(Color.black);
	    g.setFont(bigfont);
	    //g.drawString("2-D Aggregation",25,50);
	    g.setFont(normalfont);
	    pauseButton.draw(g);
	    fastButton.draw(g);
	    slowButton.draw(g);
	    restartButton.draw(g);
	    jumpToButton.draw(g);
	    zoomInButton.draw(g) ;
	    zoomOutButton.draw(g);
	    stageButton.draw(g);
	    stepButton.draw(g);
	    jumpToButton2.draw(g);
	    //arrowButton.draw(g);
	    intervalLabel.draw(g);
	    rotorPaint(g);
	}
    }
    void rotorPaint(Graphics g){
  	if (g != null) {
	    g.setColor(Color.black);
	    g.setFont(normalfont);
	    String s;
	    s = "Stage = "+r.n+" ; Step = "+r.subiteration;
	    if (!iterationLabel.text.equals(s)){
		iterationLabel.changeText(s);
		iterationLabel.wipe(g,null);
	    }
	    iterationLabel.draw(g);
	    if (zoom==0) {
		spane.setVisible(false);
		g.drawImage(buffer,400, 2, null);
	    } else {
		if (sCanvas.i != null) {
		    sCanvas.getGraphics().drawImage(sCanvas.i,0,0,null);
		}
		//sCanvas.repaint();
	    }
	}
    }


    void step() {
	r.subiterate(1);
	int numanims = 4;
	for (int i = 1 ; i <= numanims ; i++ ) {
	    r.animate =  ((double)i) / numanims;
	    if (gb != null)
		r.draw(canvasSize,canvasSize,gb);
	    rotorPaint(this.getGraphics());
	}
	return;
    }
    void stage() {
	r.iterate(1);
	if (gb != null)
	    r.draw(canvasSize,canvasSize,gb);
	rotorPaint(this.getGraphics());
	return;
    }
    public void mouseClicked(MouseEvent e) { 
	if (pauseButton.clicked(e)) {
	    pause = ! pause; 
	    if (pause) {
		pauseButton.changeText("Paused");
	    } else {
		pauseButton.changeText("Unpaused");
	    }
	    this.repaint();
	} else if (fastButton.clicked(e)) {
	    if (sleep > 25) {
		sleep = sleep / 2;
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint();
	    } else { 
		sleep = 0; 
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint(); 
	    }
	} else if (slowButton.clicked(e)) {
	    if (sleep == 0) { 
		sleep = 25; 
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint(); 
	    } else if (sleep < 8000) {
		sleep = sleep * 2;
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint();
	    }
	} else if (restartButton.clicked(e)) {
	    r.reset();
	    r.draw(canvasSize,canvasSize,gb);
	    this.repaint();
	} else if (jumpToButton.clicked(e)) {  
	    skipTo.skip(r.n);
	    this.repaint();
	    //} else if (arrowButton.clicked(e)) {
	    //r.allArrows = ! r.allArrows;
	    //if (r.allArrows) { arrowButton.changeText("All Arrows"); }
	    //else { arrowButton.changeText("Some Arrows"); }
	    //r.draw(canvasSize,canvasSize,gb);
	    //this.repaint();
	} else if (jumpToButton2.clicked(e)) {  
	    skipTo.skipEachStep(skipEach);
	    this.repaint();
	} else if (zoomInButton.clicked(e)) {  
	    zoom(+1);
	    this.repaint();
	} else if (zoomOutButton.clicked(e)) {  
	    zoom(-1);
	    this.repaint();
	} else if (stepButton.clicked(e)) {  
	    step();
	} else if (stageButton.clicked(e)) {  
	    stage();
	}
    }

    public void mouseEntered(MouseEvent e) { return; }
    public void mouseExited(MouseEvent e) { return; }
    public void mousePressed(MouseEvent e) { return; }
    public void mouseReleased(MouseEvent e) { return; }
    public void keyPressed(KeyEvent e) { 
	if (e.getKeyCode() == 32) { 
	    pause = ! pause; 
	    if (pause) {
		pauseButton.changeText("Paused");
	    } else {
		pauseButton.changeText("Unpaused");
	    }
	    this.repaint();
	} else if (e.getKeyChar() == '+' || e.getKeyChar() == '=') {
	    if (sleep > 25) {
		sleep = sleep / 2;
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint();
	    } else { 
		sleep = 0; 
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint(); 
	    }
	} else if (e.getKeyChar() == '-') {
	    if (sleep == 0) { 
		sleep = 25; 
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint(); 
	    } else if (sleep < 8000) {
		sleep = sleep * 2;
		intervalLabel.changeText("Interval = "+sleep+"ms");
		this.repaint();
	    }
	} else if (e.getKeyCode()==82 && e.getModifiers()==3) {
	    r.reset();
	    //System.out.println("r.reset();");
	    r.draw(canvasSize,canvasSize,gb);
	    this.repaint();
	    //garbage collect?
	} else if (e.getKeyChar() == 'i' ) {
	    step();
	} else if (e.getKeyChar() == 'z' ) {
	    zoom(+1);
	    this.repaint();
	} else if (e.getKeyChar() == 'x' ) {
	    zoom(-1);
	    this.repaint();
	}
	return; 
    }
    public void keyReleased(KeyEvent e) { return; }
    public void keyTyped(KeyEvent e) { return; }
    void zoom(int change) {
	zoom = zoom + change;
	if (zoom < 0) { zoom = 0; }
	if (zoom > maxZoom) { zoom = maxZoom; }
	canvasSize = square * (int)(java.lang.Math.pow(2,zoom));

	//remake the image at the right size.
	buffer = createImage(canvasSize,canvasSize);
	gb = buffer.getGraphics();
	if (gb != null) {
	    r.draw(canvasSize,canvasSize,gb);
	}
	spane.remove(sCanvas);
	sCanvas.xSize = canvasSize;
	sCanvas.ySize = canvasSize;
	sCanvas .setBounds(0,0,canvasSize,canvasSize);
	sCanvas.i = buffer;
	spane.add(sCanvas);
	if (zoom > 0) {
	    sCanvas.setVisible(true);
	    spane.setVisible(true);
	} else {
	    spane.setVisible(false);
	}
	spane.setBounds(400,2,square,square);
	System.gc();
	this.repaint();
    }
}

class SkipTo extends Frame implements ActionListener {
    TextField number;
    Button okay;
    Button cancel;
    TwoDeeAggregationApplet owner;
    int current;
    int mode;
    String title;
    public SkipTo(TwoDeeAggregationApplet o, String t) {
	super(t);
	title = t;
	owner = o;
	this.setResizable(true);
	number = new TextField(7);
	number.addActionListener(this);
	okay = new Button("Okay");
	okay.addActionListener(this);
	cancel = new Button("Cancel");
	cancel.addActionListener(this);
	this.add(number);
	this.add(cancel);
	this.add(okay);
	this.setTitle(title);
	this.setBackground(Color.white);
	this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 
	this.pack() ;
	mode = 0;
	return;
    }
    
    public int skipEachStep(int skipEach){
	number.setText(Integer.toString(skipEach));
	owner.pause = true;
	owner.pauseButton.changeText("Paused");
	mode = 1;
	this.setTitle("Skip how many stages?");
	this.show();
	this.toFront();
	return 0;
    }
    public int skip(int i) {
	this.setTitle(title);
	current = i;
	mode = 0;
	owner.pause = true;
	owner.pauseButton.changeText("Paused");
	number.setText(Integer.toString(current));
	this.show();
	this.toFront();
	return 0;
    }
    public void actionPerformed(ActionEvent e) {
	int n = 0;
	boolean badnumber = false;
	if (e.getActionCommand() == "Cancel") {
	    this.setVisible(false);  //hide();
	} else if (mode == 0) {
	    if (e.getActionCommand() == "Okay") {
		try {
		    n = Integer.parseInt(number.getText());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n <= current) { badnumber = true; }
		if (!badnumber) {
		    this.setVisible(false);  //hide();
		    owner.skip(n);
		} else {
		    number.setText(Integer.toString(current));
		}
	    } else {
		try { 
		    n = Integer.parseInt(e.getActionCommand());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n <= current) { badnumber = true; }
		if (!badnumber) {
		    this.setVisible(false);  //hide();
		    owner.skip(n);
		} else {
		    number.setText(Integer.toString(current));
		}
	    } 
	} else if (mode ==1) {
	    if (e.getActionCommand() == "Okay") {
		try {
		    n = Integer.parseInt(number.getText());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n < 0) { badnumber = true; }
		if (!badnumber) {
		    this.setVisible(false);  //hide();
		    owner.skipEachStep(n);
		} 
	    } else {
		try { 
		    n = Integer.parseInt(e.getActionCommand());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n < 0) { badnumber = true; }
		if (!badnumber) {
		    this.setVisible(false);  //hide();
		    owner.skipEachStep(n);
		} 
	    }
	}
    }
}
class ICanvas extends Canvas {
    public ICanvas(int x, int y, Image image){
	xSize = x;
	ySize = y;
	i = image;
	//graph = this.getGraphics();
    }
    public int xSize,ySize;
    public Image i;
    //public Graphics graph;
    public Dimension getPreferredSize() {
	return new Dimension(xSize,ySize);
    }
    public void paint(Graphics gr)
    {
	if (i != null) {
	    gr.drawImage(i,0,0,null);
	}
    }
}

