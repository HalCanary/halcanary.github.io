Clearlooks_FC4 GNOME/GTK/Metacity theme.

This theme is apparently copyrighted by RedHat/Fedora.  These files came from the packages:
	gtk2-engines-2.6.3-2.i386.rpm
and
	gnome-themes-2.10.1-2.i386.rpm
from Fedora Core 4.  I believe that it is therefore licensed under the GPL.  I could be wrong, because I am not quite sure how to find out the license that a particular package comes from.


To install this theme, drag+drop the original package file (Clearlooks_FC4.tar.gz) from nautilus into the gnome-theme-manager window.
