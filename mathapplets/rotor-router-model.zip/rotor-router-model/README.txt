   ###################################################################

		      Rotor Router Model Applet

   A description of the algorithm can be found in the file index.html.

   This work is copyright (C) 2003-2004 Hal Canary, University of
   Wisconsin-Madison.

   This work was supported by the University of Wisconsin.

   Hal wrote most of the code while working for Professor Jim Propp,
   who is studying the Rotor Router System. Francis Wong has assisted.

   This work comes with ABSOLUTELY NO WARRANTY. This program is free
   software; you can redistribute it and/or modify it under the terms
   of version 2 of the GNU General Public License.  A copy of the
   license was distributed in the file LICENSE.txt

   Versions:	1.0-RC 		2004-05-06
		1.0-Final 	2004-07-03

   This is the version 1.0, released 2004-07-03.  It contains a few
   bugfixes from 1.0-RC.

   To do in upcoming versions: small cosmetic changes, such as making
   arrows bolder and easier to read.  Find more bugs.  Make the applet
   work better in all JVMs.  Put the "Why does this matter?" text in
   the documentation.

   To compile this software on a unix system, 
 	$ cd /(this directory)/src/
	$ make jar

   To edit the html files, edit the files templates/*.html 
   Compile the html with:
 	$ cd /(this directory)/src/
	$ make html

   ###################################################################
	        hal at ups dot physics dot wisc dot edu
		     propp at math dot wisc dot edu
   ###################################################################
