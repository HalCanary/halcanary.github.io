TOAD Shuffler, by Hal Canary.

run the program from the command line by typing
> java Shuffle

or run the program in a java-enabled browser by opening the file
index.html.

This program is GPL'ed.  Look at the file LICENCE.txt for details.
