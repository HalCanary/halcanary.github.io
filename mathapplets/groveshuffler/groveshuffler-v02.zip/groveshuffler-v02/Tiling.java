/*
    Grove Shuffler Applet
    Copyright (C) 2001-2003  
      Hal Canary, Univerity of Wisconsin-Madison (hal@ups.physics.wisc.edu)
      Kyle Petersen, Brandeis University (tkpeters@brandeis.edu)

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
/*   (r,c)                  (0,0)
       T  T  T  T             D  A  C  C
         S  S  S                d  c  c
          T  T  T                D  G  A
            S  S       e.g,        g  f
             T  T                   A  B
               S                      b
                T                      B
                                      (2n-2,2n-2)
                
     Downward-pointing (T)          Upward-pointing (S)
                                      e        f       g
     A =  *   *            --->       *        *       *
                           --->        \      /       / \
            *              --->     *   *    *   *   *   *
        B =  *---*                   b =   *
                           --->              
               *                          *---*
     C =  *   *                      c =   *
           \               --->              \
            *                             *   *
        D =  *   *                   d =   *
                /          --->            /
               *                          *   *
    E       F       G
  *---*   *---*   *   *              a =   *
   \         /     \ /     --->      
    *       *       *                     *   *
  
 */

import java.awt.Graphics;
import java.awt.Color;

/**
 * Tiling Class:
 * this class represents a simplified grove on standard initials 
 * with three distinct colors for the edges.
 *
 * <p>We use (r,c) instead of (x,y).
 * <br>  x = c-.5*r;
 * <br>  y = 1-1/(2*sqrt(3))-(sqrt(3)/2)*(i-1);
 **/
public class Tiling extends Object {
    //private static final int MAXSIZE = 20;
    //fields
    public int n;             //current size 
    public char [] [] domArray;  // the array of dominos (triangles)
    public char [] [] newArray;  // a temporary array used for moves

    //Methods:

    /**
     * The Constructor
     * we have to go through and initilize each domino.
     **/ 
    public Tiling() {  
	n = 1;
	//init domArray
	domArray = new char [2*n-1] [2*n-1];  
	for(int r = 0 ; r < 2*n - 1 ; r++) {
	    for(int c = 0 ; c < 2*n - 1 ; c++) {
		domArray[r][c] = 'A' ;
	    }
	}
    }

    /**
     * How big is my AD?
     **/
    public int getSize() {
	return n;
    }
/**
     * fillAll() is not relevant in my current algorithm.
     **/ 
    public int fillAll() {
	return 0;
    }
    /**
     * annihilateAll() moves through the array and searches 
     * for something to destroy!!!!!
     **/
    public int annihilateAll() {
	for(int r = 0 ; r < 2*n-1 ; r++) {
	    for(int c = 0 ; c < 2*n-1 ; c++) {
		if ( (domArray[r][c] == 'E') ||
		     (domArray[r][c] == 'F') ||
                     (domArray[r][c] == 'G') ) {
		    domArray[r][c] = 'a';   
                }
	    }
	}
	return 0;
    }

    /**
     * moveAll() flips all the downward-pointing triangles
     * in domArray
     * into upward-pointing triangles in newArray.
     * it then copies the newArray to domArray.
     **/
    public int moveAll() {
	//init newArray  it's bigger in r and c direction!!
	newArray = new char [2*n+1] [2*n+1];  
	for(int r = 0 ; r < 2*n+1 ; r++) {
	    for(int c = 0 ; c < 2*n+1 ; c++) {
		newArray[r][c] = ' ' ;
	    }
	}
	for(int r = 0 ; r < n ; r++) {
	    for(int c = r ; c < n ; c++) {
		if (domArray[2*r][2*c] == 'A' ) {
                    //choose a number 0,1,2
		    int coine = (int) java.lang.Math.floor(3
			* java.lang.Math.random()) ;
		    if (coine == 0) {
                    newArray[2*r+1][2*c+1] = 'e' ;
                    }
                    else if (coine == 1) {
                    newArray[2*r+1][2*c+1] = 'f';
                    }
                    else if (coine == 2) {
                    newArray[2*r+1][2*c+1] = 'g';
                    }
		}
                else if (domArray[2*r][2*c] == 'B' ) {
		    newArray[2*r+1][2*c+1] = 'b' ;
		}
                else if (domArray[2*r][2*c] == 'C' ) {
		    newArray[2*r+1][2*c+1] = 'c' ;
		}
                else if (domArray[2*r][2*c] == 'D' ) {
		    newArray[2*r+1][2*c+1] = 'd' ;
		}
                else if (domArray[2*r][2*c] == 'a' ) {
		    newArray[2*r+1][2*c+1] = 'a' ;
		}
	    }
	}
	n++;
	//reinitialize domArray one size bigger!!!
	//then, set domArray = newArray;
	domArray = new char [2*n-1] [2*n-1] ;  
	System.gc() ;
	for(int r = 0 ; r < n-1 ; r++) {
	    for(int c = r ; c < n-1 ; c++) {
		domArray[2*r+1][2*c+1] = newArray[2*r+1][2*c+1] ;
            }
	}
        //top left corner
        if ( (domArray[1][1] == 'd' ) ||
	     (domArray[1][1] == 'f' ) ||
             (domArray[1][1] == 'g' ) ) {
	    domArray[0][0] = 'D';
        }
        else domArray[0][0] = 'A';
        //top right corner
        if ( (domArray[1][2*n-3] == 'c' ) || 
             (domArray[1][2*n-3] == 'e' ) ||
             (domArray[1][2*n-3] == 'g' ) ) {
            domArray[0][2*n-2] = 'C' ;
        }
        else domArray[0][2*n-2] = 'A' ;
        //bottom corner
        if ( (domArray[2*n-3][2*n-3] == 'b' ) || 
             (domArray[2*n-3][2*n-3] == 'e' ) ||
             (domArray[2*n-3][2*n-3] == 'f' ) ) {
            domArray[2*n-2][2*n-2] = 'B' ;
        }
        else domArray[2*n-2][2*n-2] = 'A' ;
        //top row minus corners
        for (int c = 0 ; c < n-2 ; c++) {
            if ( ( (domArray[1][2*c+1] == 'a' ) ||
                   (domArray[1][2*c+1] == 'b' ) ||
                   (domArray[1][2*c+1] == 'd' ) ||
                   (domArray[1][2*c+1] == 'f' ) ) &&
                 ( (domArray[1][2*c+3] == 'd' ) ||
                   (domArray[1][2*c+3] == 'f' ) ||
                   (domArray[1][2*c+3] == 'g' ) ) ) {
                 domArray[0][2*c+2] = 'D' ;
            }
            else if ( ( (domArray[1][2*c+1] == 'a' ) ||
                   (domArray[1][2*c+1] == 'b' ) ||
                   (domArray[1][2*c+1] == 'd' ) ||
                   (domArray[1][2*c+1] == 'f' ) ) &&
                 ( (domArray[1][2*c+3] == 'a' ) ||
                   (domArray[1][2*c+3] == 'b' ) ||
                   (domArray[1][2*c+3] == 'c' ) ||
                   (domArray[1][2*c+3] == 'e' ) ) ) {
                 domArray[0][2*c+2] = 'A' ;
            }
            else if ( ( (domArray[1][2*c+1] == 'c' ) ||
                   (domArray[1][2*c+1] == 'e' ) ||
                   (domArray[1][2*c+1] == 'g' ) ) &&
                 ( (domArray[1][2*c+3] == 'd' ) ||
                   (domArray[1][2*c+3] == 'f' ) ||
                   (domArray[1][2*c+3] == 'g' ) ) ) {
                 domArray[0][2*c+2] = 'G' ;
            }
            else domArray[0][2*c+2] = 'C';
        }
        //left side (diagonal) minus corners
        for (int c = 0 ; c < n-2 ; c++) {
            if ( ( (domArray[2*c+1][2*c+1] == 'a' ) ||
                   (domArray[2*c+1][2*c+1] == 'c' ) ||
                   (domArray[2*c+1][2*c+1] == 'd' ) ||
                   (domArray[2*c+1][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*c+3][2*c+3] == 'd' ) ||
                   (domArray[2*c+3][2*c+3] == 'f' ) ||
                   (domArray[2*c+3][2*c+3] == 'g' ) ) ) {
                 domArray[2*c+2][2*c+2] = 'D' ;
            }
            else if ( ( (domArray[2*c+1][2*c+1] == 'a' ) ||
                   (domArray[2*c+1][2*c+1] == 'c' ) ||
                   (domArray[2*c+1][2*c+1] == 'd' ) ||
                   (domArray[2*c+1][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*c+3][2*c+3] == 'a' ) ||
                   (domArray[2*c+3][2*c+3] == 'b' ) ||
                   (domArray[2*c+3][2*c+3] == 'c' ) ||
                   (domArray[2*c+3][2*c+3] == 'e' ) ) ) {
                 domArray[2*c+2][2*c+2] = 'A' ;
            }
            else if ( ( (domArray[2*c+1][2*c+1] == 'b' ) ||
                   (domArray[2*c+1][2*c+1] == 'e' ) ||
                   (domArray[2*c+1][2*c+1] == 'f' ) ) &&
                 ( (domArray[2*c+3][2*c+3] == 'd' ) ||
                   (domArray[2*c+3][2*c+3] == 'f' ) ||
                   (domArray[2*c+3][2*c+3] == 'g' ) ) ) {
                 domArray[2*c+2][2*c+2] = 'F' ;
            }
            else domArray[2*c+2][2*c+2] = 'B' ;
        }
        //right side minus corners
        for (int r = 0 ; r < n-2 ; r++) {
            if ( ( (domArray[2*r+1][2*n-3] == 'a' ) ||
                   (domArray[2*r+1][2*n-3] == 'c' ) ||
                   (domArray[2*r+1][2*n-3] == 'd' ) ||
                   (domArray[2*r+1][2*n-3] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*n-3] == 'c' ) ||
                   (domArray[2*r+3][2*n-3] == 'e' ) ||
                   (domArray[2*r+3][2*n-3] == 'g' ) ) ) {
                 domArray[2*r+2][2*n-2] = 'C' ;
            }
            else if ( ( (domArray[2*r+1][2*n-3] == 'a' ) ||
                   (domArray[2*r+1][2*n-3] == 'c' ) ||
                   (domArray[2*r+1][2*n-3] == 'd' ) ||
                   (domArray[2*r+1][2*n-3] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*n-3] == 'a' ) ||
                   (domArray[2*r+3][2*n-3] == 'b' ) ||
                   (domArray[2*r+3][2*n-3] == 'd' ) ||
                   (domArray[2*r+3][2*n-3] == 'f' ) ) ) {
                 domArray[2*r+2][2*n-2] = 'A' ;
            }
            else if ( ( (domArray[2*r+1][2*n-3] == 'b' ) ||
                   (domArray[2*r+1][2*n-3] == 'e' ) ||
                   (domArray[2*r+1][2*n-3] == 'f' ) ) &&
                 ( (domArray[2*r+3][2*n-3] == 'c' ) ||
                   (domArray[2*r+3][2*n-3] == 'e' ) ||
                   (domArray[2*r+3][2*n-3] == 'g' ) ) ) {
                 domArray[2*r+2][2*n-2] = 'E' ;
            }
            else domArray[2*r+2][2*n-2] = 'B' ;
        }
        //all of the interior
        for (int r = 0 ; r < n-3 ; r++) {
            for (int c = r+1 ; c < n-2 ; c++) {
               if ( ( (domArray[2*r+1][2*c+1] == 'a' ) ||
                   (domArray[2*r+1][2*c+1] == 'c' ) ||
                   (domArray[2*r+1][2*c+1] == 'd' ) ||
                   (domArray[2*r+1][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*c+1] == 'a' ) ||
                   (domArray[2*r+3][2*c+1] == 'b' ) ||
                   (domArray[2*r+3][2*c+1] == 'd' ) ||
                   (domArray[2*r+3][2*c+1] == 'f' ) ) &&
                 ( (domArray[2*r+3][2*c+3] == 'a' ) ||
                   (domArray[2*r+3][2*c+3] == 'b' ) ||
                   (domArray[2*r+3][2*c+3] == 'c' ) ||
                   (domArray[2*r+3][2*c+3] == 'e' ) ) ) {
                 domArray[2*r+2][2*c+2] = 'A' ;
               }
               else if ( ( (domArray[2*r+1][2*c+1] == 'a' ) ||
                   (domArray[2*r+1][2*c+1] == 'c' ) ||
                   (domArray[2*r+1][2*c+1] == 'd' ) ||
                   (domArray[2*r+1][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*c+1] == 'a' ) ||
                   (domArray[2*r+3][2*c+1] == 'b' ) ||
                   (domArray[2*r+3][2*c+1] == 'd' ) ||
                   (domArray[2*r+3][2*c+1] == 'f' ) ) &&
                 ( (domArray[2*r+3][2*c+3] == 'd' ) ||
                   (domArray[2*r+3][2*c+3] == 'f' ) ||
                   (domArray[2*r+3][2*c+3] == 'g' ) ) ) {
                 domArray[2*r+2][2*c+2] = 'D' ;
               }
               else if ( ( (domArray[2*r+1][2*c+1] == 'a' ) ||
                   (domArray[2*r+1][2*c+1] == 'c' ) ||
                   (domArray[2*r+1][2*c+1] == 'd' ) ||
                   (domArray[2*r+1][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*c+1] == 'c' ) ||
                   (domArray[2*r+3][2*c+1] == 'e' ) ||
                   (domArray[2*r+3][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*c+3] == 'd' ) ||
                   (domArray[2*r+3][2*c+3] == 'f' ) ||
                   (domArray[2*r+3][2*c+3] == 'g' ) ) ) {
                 domArray[2*r+2][2*c+2] = 'G' ;
               }
               else if ( ( (domArray[2*r+1][2*c+1] == 'a' ) ||
                   (domArray[2*r+1][2*c+1] == 'c' ) ||
                   (domArray[2*r+1][2*c+1] == 'd' ) ||
                   (domArray[2*r+1][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*c+1] == 'c' ) ||
                   (domArray[2*r+3][2*c+1] == 'e' ) ||
                   (domArray[2*r+3][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*c+3] == 'a' ) ||
                   (domArray[2*r+3][2*c+3] == 'b' ) ||
                   (domArray[2*r+3][2*c+3] == 'c' ) ||
                   (domArray[2*r+3][2*c+3] == 'e' ) ) ) {
                 domArray[2*r+2][2*c+2] = 'C' ;
               }
               else if ( ( (domArray[2*r+1][2*c+1] == 'b' ) ||
                   (domArray[2*r+1][2*c+1] == 'e' ) ||
                   (domArray[2*r+1][2*c+1] == 'f' ) ) &&
                 ( (domArray[2*r+3][2*c+1] == 'c' ) ||
                   (domArray[2*r+3][2*c+1] == 'e' ) ||
                   (domArray[2*r+3][2*c+1] == 'g' ) ) &&
                 ( (domArray[2*r+3][2*c+3] == 'a' ) ||
                   (domArray[2*r+3][2*c+3] == 'b' ) ||
                   (domArray[2*r+3][2*c+3] == 'c' ) ||
                   (domArray[2*r+3][2*c+3] == 'e' ) ) ) {
                 domArray[2*r+2][2*c+2] = 'E' ;
               }
               else if ( ( (domArray[2*r+1][2*c+1] == 'b' ) ||
                   (domArray[2*r+1][2*c+1] == 'e' ) ||
                   (domArray[2*r+1][2*c+1] == 'f' ) ) &&
                 ( (domArray[2*r+3][2*c+1] == 'a' ) ||
                   (domArray[2*r+3][2*c+1] == 'b' ) ||
                   (domArray[2*r+3][2*c+1] == 'd' ) ||
                   (domArray[2*r+3][2*c+1] == 'f' ) ) &&
                 ( (domArray[2*r+3][2*c+3] == 'd' ) ||
                   (domArray[2*r+3][2*c+3] == 'f' ) ||
                   (domArray[2*r+3][2*c+3] == 'g' ) ) ) {
                 domArray[2*r+2][2*c+2] = 'F' ;
               }
               else domArray[2*r+2][2*c+2] = 'B';
            }
        }
        newArray = null;
	System.gc();
	return 0;
    }
     /**
     * printToBuff()  prints to the StringBuffer s
     * 
     **/ 
   // public int printToBuff(StringBuffer s) {
	//for (int k = 0; k < 2*n ; k++) {
	  //  for (int l = 0; l < k; l++) {
	//	s.append(' ');
	  //  }
	    //for (int l= k; l < 2*n ; l++) {
		//s.append(' ');
	//	s.append(domArray[k][l]);
	  //  }
	   // s.append('\n');
	//}
	//return 0;
    //}

    /**
     * drawAll() 
     *
     * Tells each domino to draw itself on the graphics buffer.
     *
     * @param lx is length of each edge
     * @param ly is roughly sqrt(3)/2*lx
     * @param sizeX is the x size of region.
     * @param sizeY is the y size of region
     **/ 
    public int drawAll(int lx, int ly, int sizeX, int sizeY, Graphics gb) {
	if (lx < 1) { lx = 1 ; }
        if (ly < 1) { ly = 1 ; }
        for( int r = 0 ; r < n ; r++) {
	    for( int c = 0 ; c < n ; c++) {
		if (domArray[2*r][2*c] == 'B' ) {
		    gb.setColor(Color.blue);
		    gb.drawLine( (2*c - r)*lx + 50, r*ly + 30 ,
				(2*c - r+2)*lx + 50 , r*ly + 30 );
                }
		else if (domArray[2*r][2*c] == 'C') {
		    gb.setColor(Color.green);
		    gb.drawLine( (2*c - r)*lx + 50, r*ly + 30 ,
				(2*c - r+1)*lx + 50, (r+1)*ly + 30);    
                }
		else if (domArray[2*r][2*c] == 'D') {
		    gb.setColor(Color.red);
		    gb.drawLine( (2*c - r+2)*lx +50 , r*ly + 30 ,
				(2*c - r+1)*lx +50, (r+1)*ly + 30 );
		}
		else if (domArray[2*r][2*c] == 'E') {
		    gb.setColor(Color.blue);
		    gb.drawLine( (2*c - r)*lx +50 , r*ly + 30,
				(2*c - r+2)*lx +50 , r*ly + 30);
		    gb.setColor(Color.green);
                    gb.drawLine( (2*c - r)*lx +50 , r*ly +30 ,
				(2*c - r+1)*lx +50 , (r+1)*ly +30);
		}
                else if (domArray[2*r][2*c] == 'F') {
		    gb.setColor(Color.blue);
		    gb.drawLine( (2*c - r)*lx +50 , r*ly +30,
				(2*c - r+2)*lx +50 , r*ly +30);
		    gb.setColor(Color.red);
                    gb.drawLine( (2*c - r+2)*lx +50, r*ly + 30 ,
				(2*c - r+1)*lx +50 , (r+1)*ly +30);
		}
                else if (domArray[2*r][2*c] == 'G') {
		    gb.setColor(Color.red);
		    gb.drawLine( (2*c - r+2)*lx +50 , r*ly +30,
				(2*c - r+1)*lx +50, (r+1)*ly +30);
		    gb.setColor(Color.green);
                    gb.drawLine( (2*c - r)*lx +50 , r*ly +30,
				(2*c - r +1)*lx +50 , (r+1)*ly +30 );
		}
	    }
	}
	return 0;
    }

 }
