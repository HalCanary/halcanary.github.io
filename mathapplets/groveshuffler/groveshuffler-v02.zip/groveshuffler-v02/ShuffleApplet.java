/*
    Grove Shuffler Applet
    Copyright (C) 2001-2003  
      Hal Canary, Univerity of Wisconsin-Madison (hal@ups.physics.wisc.edu)
      Kyle Petersen, Brandeis University (tkpeters@brandeis.edu)

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
import java.applet.Applet;
import java.awt.*;

/**
 * Note:  I need to put in better comments.
 **/
public class ShuffleApplet extends Applet {
    Shuffle window;
    public void init() { }

    public void start() {
	System.gc();
        window = new Shuffle();
        window.inAnApplet = true;
        window.move(0,0);
        window.setTitle(window.title);
        window.setVisible(true);
    }

    public void stop() {
	window.dispose();
	window = null;
	System.gc();
    }
    
    public void paint(Graphics g) { }
    public boolean action(Event evt, Object arg) {
	return false;
    }
}
