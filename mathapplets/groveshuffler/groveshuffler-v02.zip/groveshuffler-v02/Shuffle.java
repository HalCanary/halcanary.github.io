/*
    Grove Shuffler Applet
    Copyright (C) 2001-2003  
      Hal Canary, Univerity of Wisconsin-Madison (hal@ups.physics.wisc.edu)
      Kyle Petersen, Brandeis University (tkpeters@brandeis.edu)

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
import java.io.*;
import java.net.*;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

public class Shuffle extends Frame implements ActionListener {
    static final int initialDominoSize = 10;
    static final int WdiamondSize = 500;
    static final int LdiamondSize = 433;
    static final String title = "GROVE Shuffler";

    boolean inAnApplet = true;
    int iter;                   // the iterator
    Image buffer;               // The graphics buffer
    Graphics gb;                // The graphicvs that hold onto the buffer.
    Button button;              // a button
    int lx;                      // x increment
    int ly;                     // y increment
    Tiling diamond;            // The AD that we are playing with
    ImageCanvas canvas;
    Choice choice;
    TextField howmany;
    Panel bPanel;
        
    public void reInit() { 
        diamond = new Tiling();
	System.gc();
        iter = 0;
	lx = 10;
        ly = 17;
    }

    public void iterateShuffle() {
        if (iter%3 == 0) {
            diamond.fillAll();
        }
        else if (iter%3 == 1) {
            diamond.annihilateAll();
        }
        else if (iter%3 == 2){
            diamond.moveAll() ;
            if ((diamond.n)*2*lx > WdiamondSize -50) {
                lx = java.lang.Math.round(WdiamondSize / (diamond.n * 2) );  
            }
            if ((diamond.n)*ly > LdiamondSize -30 ) {
                ly = java.lang.Math.round( LdiamondSize / (diamond.n) );
            }
        }
        iter++;
    }
    public void drawShuffle() {
	gb.clearRect(0,0,WdiamondSize, LdiamondSize) ;
        diamond.drawAll(lx, ly, WdiamondSize, LdiamondSize, gb);
	canvas.repaint();
    }

   public Shuffle() {
	super();
	//Set up the Frame.
	resize(WdiamondSize+100, LdiamondSize+60);
	move(0,0);
	setBackground(Color.white);
	setCursor(Frame.CROSSHAIR_CURSOR);
	setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 

        // Set up our Buttons.
	bPanel = new Panel();
	bPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 

        button = new Button( "ITERATE GROVE");
	button.addActionListener(this);
        bPanel.add(button);
        button = new Button( "NEW GROVE");
	button.addActionListener(this);
        bPanel.add(button);
        button = new Button( "Help");
	button.addActionListener(this);
        bPanel.add(button);
        button = new Button( "Exit");
	button.addActionListener(this);
        bPanel.add(button);

	bPanel.add(new Label(" Speed:"));

        choice = new Choice();
	choice.addItem("single step");
	choice.addItem("two steps");
	choice.select("single step");
        bPanel.add(choice);

	bPanel.add(new Label(" Initial Size:"));
        howmany = new TextField("1", 3);
        bPanel.add(howmany);

	add(bPanel);


        //Set up the graphics buffer.  Double Buffering!
	show();
	buffer = createImage(WdiamondSize, LdiamondSize ); 
	gb = buffer.getGraphics();
	canvas = new ImageCanvas(buffer);
	canvas.resize(WdiamondSize, LdiamondSize);
	canvas.setBackground(Color.white);
	add(canvas); 
	canvas.resize(WdiamondSize, LdiamondSize);

	//Listen for close command.
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) { killMe(); }
        });

        // Set up our diamond, do the first iteration, and paint it.
	lx = 10 ;
        ly = 8 ;

        reInit() ;
	iterateShuffle();
	drawShuffle();
    }

    public void actionPerformed(ActionEvent e) {
	if (e.getActionCommand() == "Exit" ) { killMe(); }
	else if (e.getActionCommand() == "ITERATE GROVE" ) { 
	    if (choice.getSelectedItem() == "single step")
		iterateShuffle();
	    else 
		for (int j=0; j<3; j++)
		    iterateShuffle();
	    drawShuffle();
	}
	else if (e.getActionCommand() == "NEW GROVE" ) { 
            reInit() ;
	    iterateShuffle();
	    try{ 
		int x = 0;
		x = Integer.parseInt(howmany.getText());
		if (x > 1)
		    for (int j = 0; j < 3*x -3; j++)
			iterateShuffle();
	    }
	    catch (Exception exc) { }
	    drawShuffle();
	}
    }

    public static void main(String[] args) {
        Shuffle window = new Shuffle();
        window.inAnApplet = false;
        window.move(0,0);
        window.setTitle(title);
        window.setVisible(true);
    }

    public void killMe(){
	if (inAnApplet) {
	    dispose();
	} else {
	    System.exit(0);
	}
    }
}

class ImageCanvas extends Canvas {
    Image canvasImage ;
    public ImageCanvas(Image image) { super(); canvasImage = image; }
    public void paint(Graphics g) { g.drawImage(canvasImage, 0, 0, null); }
}
