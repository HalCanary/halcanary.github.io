/*
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

/**
 * This class controlls most of the  RotorRouter Applet.  It uses the 
 * RotoRouter class.
 **/
public class RotorApplet extends Applet 
    implements Runnable, MouseListener, KeyListener {
    
    public boolean pause;
    public boolean dead;
    public int sleep;

    public Panel leftPanel;
    //    public ImageCanvas rotorCanvas;
    public Image rotorImage;
    public Graphics gb;
    public static int square = 512;

    public Thread t;
    public RotorRouter r;
    public Scrollbar speedSlider ;

    int skipEach;
    
    Font bigfont;
    Font normalfont;

    Rectangle pauseButton;
    Rectangle fastButton;
    Rectangle slowButton;
    Rectangle restartButton;
    Rectangle jumpToButton;
    Rectangle arrowButton;
    Rectangle jumpToButton2;

    SkipTo skipTo;

    /** Initialize **/
    public void init() {
	dead = false;
	pause = false;
	sleep = 400;
	this.addMouseListener(this);
	this.addKeyListener(this);
	this.setBackground(Color.white);
	this.setBackground(new Color(230,230,230));
	//this.setForeground(Color.black);
	bigfont = new Font("SansSerif",Font.PLAIN,40);
	normalfont = new Font("SansSerif",Font.PLAIN,20);
	this.setFont(normalfont);
	r = new RotorRouter(square) ;
	Thread t = new Thread(this);
	t.start();
	skipTo = new SkipTo(this,"Jump to iteration: ");
	pauseButton = new Rectangle(50,100,25,25);
	fastButton = new Rectangle(50,150,25,25);
	slowButton = new Rectangle(200,150,25,25);
	restartButton = new Rectangle(50,300,25,25);
	jumpToButton = new Rectangle(50,350,25,25);
	arrowButton = new Rectangle(50,400,25,25);
	jumpToButton2 = new Rectangle(50,500,25,25);
	skipEach = 1;
    }

    /** unpause **/
    public void start() { pause = false;}
    /** pause **/
    public void stop() { pause = true;}

    /** Kill **/
    public void destroy() { 
	r = null;
	dead = true;
	try {
	    t.interrupt();
	} 
	catch (SecurityException ex) {} 
	catch (java.lang.NullPointerException ex) {}
	t = null;
    }

    /** when you make a thread**/
    public void run() {
 	while (!dead) {
	    if (!pause){
		r.iterate(skipEach);
		this.rotorPaint(this.getGraphics()); 
	    }
	    try { 
		t.sleep(sleep); //miliseconds;
	    } catch (InterruptedException e) { }
	}
    }

    /** Skip to iteration  **/
    public void skip(int iteration) {
	pause = true;
	r.iterate(iteration - r.iteration);
	this.repaint();
    }
    public void skipEachStep(int i){
	skipEach = i;
	this.repaint();
    }
    
    //    public void update(){}

    public void paint(java.awt.Graphics g) {
	Rectangle rect;
	String s;
  	if (g != null) {
	    g.setColor(Color.black);
	    g.setFont(bigfont);
	    g.drawString("RotorRouter v0.4",25,50);
	    g.setFont(normalfont);

	    // Pause/Unpause button
	    if (pause) { s = "Paused"; } else { s = "Unpaused"; }
	    g.drawString(s,50,100);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    pauseButton = new Rectangle(rect.x+50-5, rect.y+100-5,
					rect.width+15, rect.height+10);
	    drawRect(g,pauseButton);

	    //
  	    s = "Faster";
	    g.drawString(s,50,150);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    fastButton = new Rectangle(rect.x+50-5, rect.y+150-5, 
				       rect.width+15, rect.height+10);
	    drawRect(g,fastButton);


	    //
	    s = "Slower";
	    g.drawString(s, fastButton.x+fastButton.width+32 ,150);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    slowButton = new Rectangle(rect.x+fastButton.x+fastButton.width+27,
				       rect.y+150-5,
				       rect.width+15,rect.height+10);
	    drawRect(g,slowButton);
	    
	    //
	    s = "Interval = ".concat(Integer.toString(sleep)).concat("ms");
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    g.clearRect(rect.x+50-5,rect.y+200-5,rect.width+50,rect.height+10);
	    g.drawString(s,50,200);

	    //
	    s = "Restart";
	    g.setColor(Color.black);
	    g.setFont(normalfont);
	    g.drawString(s,50,300);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    restartButton = new Rectangle(rect.x+50-5, rect.y+300-5,
					  rect.width+15, rect.height+10);
	    drawRect(g,restartButton);

	    //
	    s = "Jump To";
	    g.drawString(s,50,350);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    jumpToButton = new Rectangle(rect.x+50-5, rect.y+350-5,
					 rect.width+15, rect.height+10);
	    drawRect(g,jumpToButton);

	    //Arrow Button
	    if (r.allArrows) { s = "All Arrows"; }
	    else { s = "Some Arrows"; }
	    g.drawString(s,50,400);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    arrowButton = new Rectangle(rect.x+50-5, rect.y+400-5,
					 rect.width+15, rect.height+10);
	    drawRect(g,arrowButton);

	    //
	    s = "Skip Each Step = ".concat(Integer.toString(skipEach));
	    g.drawString(s,50,450);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    jumpToButton2 = new Rectangle(rect.x+50-5, rect.y+450-5,
					 rect.width+20, rect.height+10);
	    drawRect(g,jumpToButton2);


	    r.repaintme = true;	    
	    rotorPaint(g);
	}
    }
    void rotorPaint(Graphics g){
  	if (g != null) {
	    Rectangle rect;
	    String s;
	    
	    g.setColor(Color.black);
	    g.setFont(normalfont);

	    s = "Iteration = ".concat(Integer.toString(r.iteration));
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    g.clearRect(rect.x+50-5,rect.y+250-5,rect.width+20,rect.height+10);
	    g.drawString(s,50,250);
	    
	    r.draw(g,400,2);
	}
    }


    public void mouseClicked(MouseEvent e) { 
	Point click = e.getPoint();
	if (pauseButton.contains(click)) {
	    pause = ! pause; 
	    this.repaint();
	} else if (fastButton.contains(click)) {
	    if (sleep > 25) {
		sleep = sleep / 2;
		this.repaint();
	    } else { 
		sleep = 0; 
		this.repaint(); 
	    }
	} else if (slowButton.contains(click)) {
	    if (sleep == 0) { 
		sleep = 25; this.repaint(); 
	    } else if (sleep < 8000) {
		sleep = sleep * 2;
		this.repaint();
	    }
	} else if (restartButton.contains(click)) {
	    r.initialize();
	    this.repaint();
	} else if (jumpToButton.contains(click)) {  
	    skipTo.skip(r.iteration);
	    this.repaint();
	} else if (arrowButton.contains(click)) {
	    r.allArrows = ! r.allArrows;
	    this.repaint();
	} else if (jumpToButton2.contains(click)) {  
	    skipTo.skipEachStep(skipEach);
	    this.repaint();
	}
    }

    public void mouseEntered(MouseEvent e) { return; }
    public void mouseExited(MouseEvent e) { return; }
    public void mousePressed(MouseEvent e) { return; }
    public void mouseReleased(MouseEvent e) { return; }
    public void keyPressed(KeyEvent e) { 
	if (e.getKeyCode() == 32) { 
	    pause = ! pause; 
	    this.repaint();
	} else if (e.getKeyChar() == '+' || e.getKeyChar() == '=') {
	    if (sleep > 25) {
		sleep = sleep / 2;
		this.repaint();
	    } else { 
		sleep = 0; 
		this.repaint(); 
	    }
	} else if (e.getKeyChar() == '-') {
	    if (sleep == 0) { 
		sleep = 25; this.repaint(); 
	    } else if (sleep < 8000) {
		sleep = sleep * 2;
		this.repaint();
	    }
	} else if (e.getKeyCode()==82 && e.getModifiers()==3) {
	    r.initialize();
	    //System.out.println("r.initialize();");
	    this.repaint();
	    //garbage collect?
	}
	return; 
    }
    public void keyReleased(KeyEvent e) { return; }
    public void keyTyped(KeyEvent e) { return; }
    public void drawRect(Graphics g, Rectangle r) {
	g.drawRect(r.x, r.y, r.width, r.height);
    }
}

class SkipTo extends Frame implements ActionListener {
    TextField number;
    Button okay;
    Button cancel;
    RotorApplet owner;
    int current;
    int mode;
    String title;
    public SkipTo(RotorApplet o, String t) {
	super(t);
	title = t;
	owner = o;
	this.setResizable(true);
	number = new TextField(7);
	number.addActionListener(this);
	okay = new Button("Okay");
	okay.addActionListener(this);
	cancel = new Button("Cancel");
	cancel.addActionListener(this);
	this.add(number);
	this.add(cancel);
	this.add(okay);
	this.setTitle(title);
	this.setBackground(Color.white);
	this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 
	this.pack() ;
	mode = 0;
	return;
    }
    
    public int skipEachStep(int skipEach){
	number.setText(Integer.toString(skipEach));
	owner.pause = true;
	mode = 1;
	this.setTitle("How Many Iterations Each Step?");
	this.show();
	this.toFront();
	return 0;
    }
    public int skip(int i) {
	this.setTitle(title);
	current = i;
	mode = 0;
	owner.pause = true;
	number.setText(Integer.toString(current));
	this.show();
	this.toFront();
	return 0;
    }
    public void actionPerformed(ActionEvent e) {
	int n = 0;
	boolean badnumber = false;
	if (e.getActionCommand() == "Cancel") {
	    hide();
	} else if (mode == 0) {
	    if (e.getActionCommand() == "Okay") {
		try {
		    n = Integer.parseInt(number.getText());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n <= current) { badnumber = true; }
		if (!badnumber) {
		    hide();
		    owner.skip(n);
		} else {
		    number.setText(Integer.toString(current));
		}
	    } else {
		try { 
		    n = Integer.parseInt(e.getActionCommand());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n <= current) { badnumber = true; }
		if (!badnumber) {
		    hide();
		    owner.skip(n);
		} else {
		    number.setText(Integer.toString(current));
		}
	    } 
	} else if (mode ==1) {
	    if (e.getActionCommand() == "Okay") {
		try {
		    n = Integer.parseInt(number.getText());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n <= 0) { badnumber = true; }
		if (!badnumber) {
		    hide();
		    owner.skipEachStep(n);
		} 
	    } else {
		try { 
		    n = Integer.parseInt(e.getActionCommand());
		} catch (NumberFormatException badness) {
		    badnumber = true;
		}
		if (n <= 0) { badnumber = true; }
		if (!badnumber) {
		    hide();
		    owner.skipEachStep(n);
		} 
	    }
	}
    }
}
