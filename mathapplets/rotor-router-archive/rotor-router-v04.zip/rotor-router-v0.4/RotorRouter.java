/* 
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
import java.awt.*;

/** Mathematical Model of the Rotor Router Object **/
public class RotorRouter {
    public boolean allArrows;
    public boolean repaintme;
    public int maxSize ;
    public int aSize;
    char [] [] sandpile ;
    int middle;
    int posR;
    int posC;
    
    public int [] recentR ;
    public int [] recentC ;

    public int iteration;
    public boolean badness;

    int lastR;
    int lastC;

    Color up;
    Color down;
    Color right;
    Color left;
	
    /** Creates a new empty RotorRouter **/
    public RotorRouter(int n) {
	maxSize = n;
	initialize();
    } 

    public void initialize() {
	allArrows = true;
	iteration = 0;
	repaintme = true;
	badness = false;
	aSize = 7;
	sandpile = new char [aSize][aSize];
	for(int r = 0 ; r < aSize ; r++) {
	    for(int c = 0 ; c < aSize ; c++) {
		sandpile[r][c] = ' ' ;
	    }
	}
	middle = 3;
	lastR=-1;
	lastC=-1; //just in case.
	recentC = new int [aSize] ;
	recentR = new int [aSize] ;
	up     = new Color(255,63,63); 
	down   = Color.green;
	right  = new Color(127,127,255); 
	left   = Color.yellow;
    }

    public int iterate(int number) {
	boolean filled = false;
	int num;
	for(num = 0; (num < number) && (!filled); num++) {
	    iteration++;
	    int subiteration = 0;
	    posR = middle;
	    posC = middle;
	    boolean done = false;
	    while ((! done) && (! badness) && (! filled)) {
		recentR [subiteration] = posR;
		recentC [subiteration] = posC;
		subiteration++;
		if (subiteration == recentR.length) {
		    int oldsize = recentR.length;
		    int tempR [] = recentR;
		    int tempC [] = recentC;
		    recentC = new int [oldsize * 2] ;
		    recentR = new int [oldsize * 2] ;
		    for(int i = 0; i < oldsize; i++) {
			recentR [i] = tempR [i];
			recentC [i] = tempC [i];
		    }
		    //garbage collect, maybe?
		}
		//System.err.println(sandpile.length);
		//System.err.println(posC);
		if (sandpile[posR][posC] == ' ') {
		    sandpile[posR][posC] = 'l';
		    recentR [subiteration] = -1;  // This indicates that 
		    recentC [subiteration] = -1;  //     we are done! 
		    lastR = posR;
		    lastC = posC;
		    done = true;
		} else if (sandpile[posR][posC] == 'u') {
		    sandpile[posR][posC] = 'r';
		    posC++;
		    if (posC == aSize) { filled = !resizeArray(); } 
		} else if (sandpile[posR][posC] == 'r') {
		    sandpile[posR][posC] = 'd';
		    posR++;
		    if (posR == aSize) { filled = !resizeArray(); }
		} else if (sandpile[posR][posC] == 'd') {
		    sandpile[posR][posC] = 'l';
		    posC--;
		    if (posC < 0) { filled = !resizeArray(); }
		} else if (sandpile[posR][posC] == 'l') {
		    sandpile[posR][posC] = 'u';
		    posR--;
		    if (posR < 0) { filled = !resizeArray(); }
		} else {
		    System.out.println("shouldn't happen! ");	
		}		
	    }
	} 
	return num;
    }
    /** return true if successfull. **/
    private boolean resizeArray() {
	//System.out.println("Resizing! \n");	
	repaintme = true;
        int newArraySize = aSize * 2 + 1;
	if (newArraySize > maxSize) {
	    //do something here to stop this!!!!
	    badness = true;
	    return false;
	}
	int newMiddle = aSize; //(newArraySize - 1) / 2;  
	int shift = newMiddle - middle;
	char [] [] oldPile = sandpile;	
        sandpile = new char[newArraySize][newArraySize];
        for(int r = 0 ; r < newArraySize ; r++) {
            for(int c = 0 ; c < newArraySize ; c++) {
                sandpile[r][c] = ' ';
            }
        }
	//25% wasteful!  What to do? Worry about smething else!
        for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
                sandpile[r+shift][c+shift] = oldPile[r][c] ;
            }
        }
	oldPile = null;
	//garbage collect???
        middle = newMiddle;
	posR = posR + shift;
	posC = posC + shift;
	aSize = newArraySize;
	return true;
    }

    public void printArray() {
	System.out.print("Grain number ");
	System.out.println(iteration);
	for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
		System.out.print(sandpile[r][c]);
		System.out.print(' ');
	    }
	    System.out.print('\n');
	}
	System.out.print('\n');
    }

    public void draw(Graphics g,int x,int y) {
	int block = maxSize / aSize;
	//g.setBackground(Color.white);
	x++; y++;
	if (repaintme) {
	    g.clearRect(x,y,maxSize,maxSize) ;
	    g.setColor(Color.white);
	    g.fillRect(x,y,aSize * block,aSize * block) ;
	    repaintme = false;
	}
	g.setColor(Color.black);
	g.drawRect(x-1,y-1,(aSize * block)+1,(aSize * block)+1) ;
        for (int r = 0 ; r < aSize ; r++) {
            for (int c = 0 ; c < aSize ; c++) {
		if (sandpile[r][c] == 'u') {
		    g.setColor(up);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'u',x,y,block);}
		} else if (sandpile[r][c] == 'r') {
		    g.setColor(right);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'r',x,y,block);}
		} else if (sandpile[r][c] == 'd') {
		    g.setColor(down);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'d',x,y,block);}
		} else if (sandpile[r][c] == 'l') {
		    g.setColor(left);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		    if (allArrows && block >= 5) {
			drawArrow(g,r,c,'l',x,y,block);}
		} 
	    }
	}
	if (block >= 5) {
	    if (allArrows) {
		if (lastR != -1) {
		    drawArrow(g,lastR,lastC,'X',x,y,block);
		}
	    } else {
		g.setColor(Color.black);
		for (int i = 0 ; i < recentR.length ; i++) {
		    if (recentR[i] == -1) {
			i = recentR.length; //we are done.  Hack!
		    } else {
			char dir = sandpile[recentR[i]][recentC[i]] ;
			if (i < recentR.length-1 ) {
			    if (recentR[i+1] == -1 )
				dir = 'X';
			}
			drawArrow(g,recentR[i],recentC[i],dir,x,y,block);
		    }
 		}
 	    }
	}
    }
    /**
       r,c row and column
     **/
    void drawArrow(Graphics g, int r, int c, char dir,
		   int x, int y, int b) {
	int cX = x + (b*c) + (b/2);
	int cY = y + (b*r) + (b/2);
	g.setColor(Color.black);
	if (dir == 'u' || dir =='d') {
	    g.drawLine(cX, cY-(b/4), cX, cY+(b/4));
	    if (dir == 'u') {
		g.drawLine(cX, cY-(b/4), cX+(b/4), cY);
		g.drawLine(cX, cY-(b/4), cX-(b/4), cY);
	    } else {
		g.drawLine(cX, cY+(b/4), cX+(b/4), cY);
		g.drawLine(cX, cY+(b/4), cX-(b/4), cY);
	    }
	} else if (dir == 'r' || dir =='l') {
	    g.drawLine(cX-(b/4), cY, cX+(b/4), cY);
	    if (dir == 'r') {
		g.drawLine(cX+(b/4), cY, cX, cY+(b/4));
		g.drawLine(cX+(b/4), cY, cX, cY-(b/4));
	    } else {
		g.drawLine(cX-(b/4), cY, cX, cY+(b/4));
		g.drawLine(cX-(b/4), cY, cX, cY-(b/4));
	    }
	} else if (dir == 'X') {
 	    g.drawRect((b*c)+x,(b*r)+y,b-1,b-1);
 	}

// 	if (dir == 'u') { // it was 'l'
// 	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+b-1, y+(b*r)+(b/2));
// 	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c), y+(b*r)+(b/2));
// 	    g.drawLine(x+(b*c)+(b/2), y+(b*r)+b-1, x+(b*c), y+(b*r)+(b/2));
// 	} else if (dir == 'r') { // it was 'u'
// 	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c)+(b/2), y+(b*r)+b-1);
// 	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r));
// 	    g.drawLine(x+(b*c)+b-1, y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r));
// 	} else if (dir == 'd') { // it was 'r'
// 	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+b-1, y+(b*r)+(b/2));
// 	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c)+b-1, y+(b*r)+(b/2));
// 	    g.drawLine(x+(b*c)+(b/2), y+(b*r)+b-1, x+(b*c)+b-1, y+(b*r)+(b/2));
// 	} else if (dir == 'l') { // it was 'd'
// 	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c)+(b/2), y+(b*r)+b);
// 	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r)+b);
// 	    g.drawLine(x+(b*c)+b-1, y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r)+b-1);
// 	} else if (dir == 'X') {
// 	    g.drawRect((b*c)+x,(b*r)+y,b-1,b-1);
// 	}
    }

    public static void main(String[] args) {
	RotorRouter r;
	r = new RotorRouter(550) ;
	r.iterate(900);
	while (! r.badness) {
	    r.printArray();
	    try { 
		Thread.sleep(500);  //miliseconds;
	    } catch (InterruptedException e) { }
	    r.iterate(1);
	}
    }
}
