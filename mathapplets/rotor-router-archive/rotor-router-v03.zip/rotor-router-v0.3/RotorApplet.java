/* 
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;

public class RotorApplet extends Applet 
    implements Runnable, MouseListener, KeyListener {
    
    public boolean pause;
    public boolean dead;
    public int sleep;

    public Panel leftPanel;
    //    public ImageCanvas rotorCanvas;
    public Image rotorImage;
    public Graphics gb;
    public static int square = 550;

    public Thread t;
    public RotorRouter r;
    public Scrollbar speedSlider ;

    Font bigfont;
    Font normalfont;

    int pauseButtonX;
    int pauseButtonY;
    int pauseButtonW;
    int pauseButtonH;
    int fastButtonX;
    int fastButtonY;
    int fastButtonW;
    int fastButtonH;
    int slowButtonX;
    int slowButtonY;
    int slowButtonW;
    int slowButtonH;
    int restartButtonX;
    int restartButtonY;
    int restartButtonW;
    int restartButtonH;
    
    public void init() {
	dead = false;
	pause = false;
	sleep = 400;
	this.addMouseListener(this);
	this.addKeyListener(this);
	this.setBackground(Color.white);
	this.setBackground(new Color(230,230,230));
	//this.setForeground(Color.black);
	bigfont = new Font("SansSerif",Font.PLAIN,40);
	normalfont = new Font("SansSerif",Font.PLAIN,20);
	this.setFont(normalfont);
	r = new RotorRouter(square) ;
	Thread t = new Thread(this);
	t.start();
    }

    public void start() { pause = false;}
    public void stop() { pause = true;}

    public void destroy() { 
	r = null;
	dead = true;
	try {
	    t.interrupt();
	} 
	catch (SecurityException ex) {} 
	catch (java.lang.NullPointerException ex) {}
	t = null;
    }

    public void run() {
 	while (!dead) {
	    if (!pause){
		r.iterate(1);
		this.rotorPaint(this.getGraphics()); 
	    }
	    try { 
		t.sleep(sleep); //miliseconds;
	    } catch (InterruptedException e) { }
	}
    }

    //    public void update(){}

    public void paint(java.awt.Graphics g) {
  	if (g != null) {
	    g.setFont(bigfont);
	    g.drawString("RotorRouter v0.3",25,50);
	    g.setColor(Color.black);
	    r.repaintme = true;	    
	    rotorPaint(g);
	}
    }

    void rotorPaint(java.awt.Graphics g){
  	if (g != null) {
	    Rectangle rect;
	    String s;

	    g.setColor(Color.black);
	    g.setFont(normalfont);

	    if (pause) { s = "Paused"; } else { s = "Unpaused"; }
	    g.drawString(s,50,100);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    pauseButtonX = rect.x+50-5;
	    pauseButtonY = rect.y+100-5;
	    pauseButtonW = rect.width+20;
	    pauseButtonH = rect.height+10;
	    g.drawRect(pauseButtonX,pauseButtonY,pauseButtonW,pauseButtonH);
	    
	    s = "Faster";
	    g.drawString(s,50,150);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    fastButtonX = rect.x+50-5;
	    fastButtonY = rect.y+150-5;
	    fastButtonW = rect.width+20;
	    fastButtonH = rect.height+10;
	    g.drawRect(fastButtonX,fastButtonY,fastButtonW,fastButtonH);
	    
	    s = "Slower";
	    g.drawString(s,fastButtonX +fastButtonW + 32 ,150);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    slowButtonX = rect.x+fastButtonX +  fastButtonW + 32-5;
	    slowButtonY = rect.y+150-5;
	    slowButtonW = rect.width+20;
	    slowButtonH = rect.height+10;
	    g.drawRect(slowButtonX,slowButtonY,slowButtonW,slowButtonH);
	    
	    s = "Interval = ".concat(Integer.toString(sleep)).concat("ms");
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    g.clearRect(rect.x+50-5,rect.y+200-5,rect.width+20,rect.height+10);
	    g.drawString(s,50,200);

	    s = "Iteration = ".concat(Integer.toString(r.iteration));
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    g.clearRect(rect.x+50-5,rect.y+250-5,rect.width+20,rect.height+10);
	    g.drawString(s,50,250);
	    
	    s = "Restart";
	    g.setColor(Color.black);
	    g.setFont(normalfont);
	    g.drawString(s,50,300);
	    rect = g.getFontMetrics().getStringBounds(s,g).getBounds();
	    restartButtonX = rect.x+50-5;
	    restartButtonY = rect.y+300-5;
	    restartButtonW = rect.width+20;
	    restartButtonH = rect.height+10;
	    g.drawRect(restartButtonX,restartButtonY,
		       restartButtonW,restartButtonH);
	    
	    //gb.clearRect(0,0,square,square) ;
	    //gb.drawLine(10,10, square-10,square-10);
	    //gb.drawLine(10,square-10,square-10,10);
	    //r.repaintme = true;
	    r.draw(g,400,0);
	}
    }



    public void mouseClicked(MouseEvent e) { 
	if ((e.getX() >= pauseButtonX ) && 
	    (e.getX() <= pauseButtonW + pauseButtonX ) &&
	    (e.getY() >= pauseButtonY ) && 
	    (e.getY() <= pauseButtonH + pauseButtonY )) {
	    pause = ! pause; 
	    this.repaint();
	} else if ((e.getX() >= fastButtonX ) && 
		   (e.getX() <= fastButtonW + fastButtonX ) &&
		   (e.getY() >= fastButtonY ) && 
		   (e.getY() <= fastButtonH + fastButtonY )) {
	    if (sleep > 25) {
		sleep = sleep / 2;
		this.repaint();
	    } else { 
		sleep = 0; 
		this.repaint(); 
	    }
	} else if ((e.getX() >= slowButtonX ) && 
		   (e.getX() <= slowButtonW + slowButtonX ) &&
		   (e.getY() >= slowButtonY ) && 
		   (e.getY() <= slowButtonH + slowButtonY )) {
	    if (sleep == 0) { 
		sleep = 25; this.repaint(); 
	    } else if (sleep < 8000) {
		sleep = sleep * 2;
		this.repaint();
	    }
	}else if ((e.getX() >= restartButtonX ) && 
		   (e.getX() <= restartButtonW + restartButtonX ) &&
		   (e.getY() >= restartButtonY ) && 
		   (e.getY() <= restartButtonH + restartButtonY )) {
	    r.initialize();
	    this.repaint();
	}
    }
    public void mouseEntered(MouseEvent e) { return; }
    public void mouseExited(MouseEvent e) { return; }
    public void mousePressed(MouseEvent e) { return; }
    public void mouseReleased(MouseEvent e) { return; }
    public void keyPressed(KeyEvent e) { 
	if (e.getKeyCode() == 32) { 
	    pause = ! pause; 
	    this.repaint();
	} else if (e.getKeyChar() == '+' || e.getKeyChar() == '=') {
	    if (sleep > 25) {
		sleep = sleep / 2;
		this.repaint();
	    } else { 
		sleep = 0; 
		this.repaint(); 
	    }
	} else if (e.getKeyChar() == '-') {
	    if (sleep == 0) { 
		sleep = 25; this.repaint(); 
	    } else if (sleep < 8000) {
		sleep = sleep * 2;
		this.repaint();
	    }
	} else if (e.getKeyCode()==82 && e.getModifiers()==3) {
	    r.initialize();
	    //System.out.println("r.initialize();");
	    this.repaint();
	    //garbage collect?
	}
	return; 
    }
    public void keyReleased(KeyEvent e) { return; }
    public void keyTyped(KeyEvent e) { return; }
}

// class ImageCanvas extends Canvas {
//     Image canvasImage ;
//     public ImageCanvas(Image image) { super(); canvasImage = image; }
//     public void paint(Graphics g) { g.drawImage(canvasImage, 0, 0, null); }
// }
