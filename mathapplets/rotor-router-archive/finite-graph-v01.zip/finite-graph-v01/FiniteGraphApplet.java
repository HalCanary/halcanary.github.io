/*
    Finite Graph Applet
    Copyright (C) 2001-2003  
      Hal Canary, Univerity of Wisconsin-Madison (hal@ups.physics.wisc.edu)
      Kyle Petersen, Brandeis University (tkpeters@brandeis.edu)

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
import java.io.*;
import java.net.*;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.Applet;

/**
 * Note:  I need to put in better comments.
 **/
public class FiniteGraphApplet extends Applet implements ActionListener {
    static final int canvasWidth = 813;
    static final int canvasHeight = 400;

    ICanvas canvas;
    Button button;              // a button
    FiniteGraph graph;          // The MAthSystem we are playing with
    FiniteGraphA graphA;          
    FiniteGraphB graphB;          
    FiniteGraphC graphC;          
    Panel bPanel;
    Label label1,label2;
    Choice choice;

    public void init() { 
	this.removeAll();
	this.setBackground(new Color(230,230,230));
	setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 

        // Set up our Buttons.
	bPanel = new Panel();
	bPanel.setBackground(new Color(230,230,230));
	bPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 

        button = new Button( "Step");
	button.addActionListener(this);
        bPanel.add(button);
        button = new Button( "Stage");
	button.addActionListener(this);
        bPanel.add(button);
        button = new Button( "Reset");
	button.addActionListener(this);
        bPanel.add(button);

	label1 = new Label("  left = 0    ");
	label2 = new Label("  right = 0    ");
	bPanel.add(label1);
	bPanel.add(label2);

	choice = new Choice();
	choice.addItem("Graph A");
	choice.addItem("Graph B");
	choice.addItem("Graph C");
	choice.select("Graph A");
        bPanel.add(choice);

	add(bPanel);
	setVisible(true);

	canvas = new ICanvas(canvasWidth,canvasHeight,this);
	add(canvas);

	graphA = new FiniteGraphA() ;
	graphB = new FiniteGraphB() ;
	graphC = new FiniteGraphC() ;
	graph = graphA;
	drawCanvas();
    }

    public void start() { }
    public void stop() { }

    public void destroy() { 
	System.gc();
    }
 
    public void paint(Graphics g) {  }

    public void drawCanvas() {
	graph.draw(canvas.xSize,canvas.ySize,canvas.g);
	canvas.draw();
    }

    public void actionPerformed(ActionEvent e) {
	if (e.getActionCommand() == "Step" ) { 
	    graph.subiterate(1);
	    label1.setText(("  left = " + graph.total1) + "    ");
	    label2.setText(("  right = " + graph.total2) + "    ");
	    drawCanvas();
	} else if (e.getActionCommand() == "Stage" ) { 
	    graph.iterate(1);
	    label1.setText(("  left = "+graph.total1)+"    ");
	    label2.setText(("  right = "+graph.total2)+"    ");
	    drawCanvas();
	} else if (e.getActionCommand() == "Reset" ) { 
	    if (choice.getSelectedItem() == "Graph A")
		graph = graphA;
	    else if (choice.getSelectedItem() == "Graph B")
		graph = graphB;
	    else if (choice.getSelectedItem() == "Graph C")
		graph = graphC;
	    graph.reset();
	    label1.setText(("  left = "+graph.total1)+"    ");
	    label2.setText(("  right = "+graph.total2)+"    ");
	    drawCanvas();
	} 
    }
}

class ICanvas extends Canvas {
    public ICanvas(int x, int y,Applet owner){
	super();
	xSize = x;
        ySize = y;
        i = owner.createImage(x,y);
	if (i == null) {
	    System.out.println("image is null!");
	} else 
	    g = i.getGraphics();
	this.setSize(xSize,ySize);
        graph = this.getGraphics();
    }
    public int xSize,ySize;
    public Image i; //image
    public Graphics g; //graphics of image
    public Graphics graph; //grpahics of this.
    public Dimension getPreferredSize() {
        return new Dimension(xSize,ySize);
    }
    public void draw() {
        if (i != null) {
	    if (graph == null)
		graph = this.getGraphics();
	    graph.drawImage(i,0,0,null);
        }
    }
    //public void update(Graphics g) { }
    public void paint(Graphics gr) { 
	gr.drawImage(i,0,0,null);
    }
}
