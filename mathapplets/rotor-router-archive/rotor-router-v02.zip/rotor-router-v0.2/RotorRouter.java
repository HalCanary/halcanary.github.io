/* 
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.
    See the README.txt file for version information,
*/
import java.awt.*;

/** Mathematical Model of the Rotor Router Object **/
public class RotorRouter {
    public int maxSize ;
    public int aSize;
    char [] [] sandpile ;
    int middle;
    int posR = middle;
    int posC = middle;
    
    public int [] recentR ;
    public int [] recentC ;

    public int iteration;
    public boolean badness;

    /** Creates a new empty RotorRouter **/
    public RotorRouter(int n) {
	maxSize = n;
	iteration = 0;
	badness = false;
	aSize = 9;
	sandpile = new char [aSize][aSize];
	for(int r = 0 ; r < aSize ; r++) {
	    for(int c = 0 ; c < aSize ; c++) {
		sandpile[r][c] = ' ' ;
	    }
	}
	middle = 4;
	middle = 4;

	recentC = new int [aSize] ;
	recentR = new int [aSize] ;
    } 

    public void iterate(int number) {
	for(int num = 0; num < number; num++) {
	    iteration++;
	    int subiteration = 0;
	    posR = middle;
	    posC = middle;
	    boolean done = false;
	    while ((! done) && (! badness)) {
		recentR [subiteration] = posR;
		recentC [subiteration] = posC;
		subiteration++;
		if (subiteration == recentR.length) {
		    int oldsize = recentR.length;
		    int tempR [] = recentR;
		    int tempC [] = recentC;
		    recentC = new int [oldsize * 2] ;
		    recentR = new int [oldsize * 2] ;
		    for(int i = 0; i < oldsize; i++) {
			recentR [i] = tempR [i];
			recentC [i] = tempC [i];
		    }
		    //garbage collect, maybe?
		}
		if (sandpile[posR][posC] == ' ') {
		    sandpile[posR][posC] = 'u';
		    recentR [subiteration] = -1;  // This indicates that 
		    recentC [subiteration] = -1;  //     we are done! 
		    done = true;
		} else if (sandpile[posR][posC] == 'u') {
		    sandpile[posR][posC] = 'r';
		    posR--;
		    if (posR < 0) { resizeArray(); }
		} else if (sandpile[posR][posC] == 'r') {
		    sandpile[posR][posC] = 'd';
		    posC++;
		    if (posC == aSize) { resizeArray(); } 
		} else if (sandpile[posR][posC] == 'd') {
		    sandpile[posR][posC] = 'l';
		    posR++;
		    if (posR == aSize) { resizeArray(); }
		} else if (sandpile[posR][posC] == 'l') {
		    sandpile[posR][posC] = 'u';
		    posC--;
		    if (posC < 0) { resizeArray(); }
		} else {
		    System.out.println("shouldn't happen! ");	
		}		
	    }
	} 
    }
    private boolean resizeArray() {
	//System.out.println("Resizing! \n");	
        int newArraySize = aSize * 2 + 1;
	if (newArraySize > maxSize) {
	    //do something here to stop this!!!!
	    badness = true;
	    return false;
	}
	int newMiddle = aSize; //(newArraySize - 1) / 2;  
	int shift = newMiddle - middle;
	char [] [] oldPile = sandpile;	
        sandpile = new char[newArraySize][newArraySize];
        for(int r = 0 ; r < newArraySize ; r++) {
            for(int c = 0 ; c < newArraySize ; c++) {
                sandpile[r][c] = ' ';
            }
        }
	//25% wasteful!  What to do? Worry about smething else!
        for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
                sandpile[r+shift][c+shift] = oldPile[r][c] ;
            }
        }
	oldPile = null;
	//garbage collect???
        middle = newMiddle;
	posR = posR + shift;
	posC = posC + shift;
	aSize = newArraySize;
	return true;
    }

    public void printArray() {
	System.out.print("Grain number ");
	System.out.println(iteration);
	for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
		System.out.print(sandpile[r][c]);
		System.out.print(' ');
	    }
	    System.out.print('\n');
	}
	System.out.print('\n');
    }

    public void draw(Graphics g,int x,int y) {
	int block = maxSize / aSize;
	//g.setBackground(Color.white);
	g.clearRect(x,y,maxSize,maxSize) ;
	g.setColor(Color.white);
	g.fillRect(x,y,aSize * block,aSize * block) ;
	g.setColor(Color.black);
	g.drawRect(x,y,aSize * block,aSize * block) ;
        for (int r = 0 ; r < aSize ; r++) {
            for (int c = 0 ; c < aSize ; c++) {
		if (sandpile[r][c] == 'u') {
		    g.setColor(Color.yellow);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		} else if (sandpile[r][c] == 'r') {
		    g.setColor(Color.green);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		} else if (sandpile[r][c] == 'd') {
		    g.setColor(Color.blue);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		} else if (sandpile[r][c] == 'l') {
		    g.setColor(Color.red);
		    g.fillRect((block * c) + x, (block * r) + y, block,block);
		} 
	    }
	}
	if (block >= 5) {
	    g.setColor(Color.black);
 	    for (int i = 0 ; i < recentR.length ; i++) {
 		if (recentR[i] == -1) {
 		    i = recentR.length; //we are done.  Hack!
 		} else {
		    char dir = sandpile[recentR[i]][recentC[i]] ;
		    if (i < recentR.length-1 ) {
			if (recentR[i+1] == -1 )
			    dir = 'X';
		    }
		    drawArrow(g,recentR[i],recentC[i],dir,x,y,block);
		    // g.drawRect((block * recentC[i]) + x, 
		    //	(block * recentR[i]) + y,  block, block);
 		}
 	    }
	}
    }

    void drawArrow(Graphics g, int r, int c, char dir,
		   int x, int y, int b) {
	if (dir == 'u') { // it was 'l'
	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+b, y+(b*r)+(b/2));
	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c), y+(b*r)+(b/2));
	    g.drawLine(x+(b*c)+(b/2), y+(b*r)+b, x+(b*c), y+(b*r)+(b/2));
	} else if (dir == 'r') { // it was 'u'
	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c)+(b/2), y+(b*r)+b);
	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r));
	    g.drawLine(x+(b*c)+b, y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r));
	} else if (dir == 'd') { // it was 'r'
	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+b, y+(b*r)+(b/2));
	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c)+b, y+(b*r)+(b/2));
	    g.drawLine(x+(b*c)+(b/2), y+(b*r)+b, x+(b*c)+b, y+(b*r)+(b/2));
	} else if (dir == 'l') { // it was 'd'
	    g.drawLine(x+(b*c)+(b/2), y+(b*r), x+(b*c)+(b/2), y+(b*r)+b);
	    g.drawLine(x+(b*c), y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r)+b);
	    g.drawLine(x+(b*c)+b, y+(b*r)+(b/2), x+(b*c)+(b/2), y+(b*r)+b);
	} else if (dir == 'X') {
	    g.drawRect((b*c)+x,(b*r)+y,b,b);
	}
    }

    public static void main(String[] args) {
	RotorRouter r;
	r = new RotorRouter(550) ;
	r.iterate(900);
	while (! r.badness) {
	    r.printArray();
	    try { 
		Thread.sleep(500);  //miliseconds;
	    } catch (InterruptedException e) { }
	    r.iterate(1);
	}
    }
}
