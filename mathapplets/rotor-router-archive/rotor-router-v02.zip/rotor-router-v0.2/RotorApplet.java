/* 
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/

import java.applet.Applet;
import java.awt.*;

public class RotorApplet extends Applet implements Runnable{
    public Panel leftPanel;
    public ImageCanvas rotorCanvas;
    public Image rotorImage;
    public Graphics gb;
    public static int square = 550;

    public Thread t;
    public RotorRouter r;
    public Scrollbar speedSlider ;

    public void init() { }

    public void start() { 
	//GridBagLayout gridbag = new GridBagLayout();
	//GridBagConstraints c = new GridBagConstraints();
	//this.setLayout(gridbag);

	//this.setLayout(new GridLayout(1,2));
	//this.setBackground(new Color(255,255,255));
	this.setBackground(new Color(230,230,230));
	this.setForeground(new Color(0,0,0));
 	this.setFont(new Font("SansSerif",Font.PLAIN,40));

// 	leftPanel = new Panel();
// 	//leftPanel.setLayout(new GridLayout(4,1));
// 	leftPanel.setBackground(new Color(230,230,230));
// 	leftPanel.setForeground(new Color(0,0,0));
// 	leftPanel.setFont(new Font("SansSerif",Font.PLAIN,20));
// 	leftPanel.resize(400,550);
// 	//leftPanel.add(new Label("RotorRouter v0.2"));
// 	//this.add(new Label("RotorRouter v0.2"));		 
// 	//gridbag.setConstraints(leftPanel, c);
// 	//leftPanel.resize(400,square);
// 	leftPanel.resize(400,550);
// 	this.add(leftPanel);

// 	leftPanel.setFont(new Font("SansSerif",Font.PLAIN,20));
//         leftPanel.add(new Label("Speed:"));

//	speedSlider = new Scrollbar(Scrollbar.HORIZONTAL, 10, 1, 1, 10);
// 	speedSlider.setBounds(20,20,200,10);
// 	speedSlider.setSize(200,20);
// 	leftPanel.add(speedSlider);
  
	//rotorImage = createImage(square,square);
	//gb = rotorImage.getGraphics();
	//rotorCanvas = new ImageCanvas(rotorImage);
	//	rotorCanvas.resize(square,square);
	//rotorCanvas.setBackground(Color.blue);
	//rotorCanvas.setForeground(Color.blue);
	//gb.clearRect(0,0,square,square) ;
	//gridbag.setConstraints(rotorCanvas, c);
	//this.add(rotorCanvas);


	//show();
	r = new RotorRouter(square) ;
	Thread t = new Thread(this);
	t.start();
	//show();
    }

    public void run() {
 	while (true) {
	    r.iterate(1);
	    this.repaint();
	    try { 
		t.sleep(2000);  //miliseconds;
	    } catch (InterruptedException e) { }
	}
    }

    public void stop() { }

    public void paint(java.awt.Graphics g) {
	g.drawString("RotorRouter v0.2",50,50);
	r.draw(g,400,0);
	//gb.clearRect(0,0,square,square) ;
	//gb.drawLine(10,10, square-10,square-10);
	//gb.drawLine(10,square-10,square-10,10);
	//g.drawString("Welcome to Java Programming!",50,50);
    }

    public boolean action(Event evt, Object arg) {
	return false;
    }
}

class ImageCanvas extends Canvas {
    Image canvasImage ;
    public ImageCanvas(Image image) { super(); canvasImage = image; }
    public void paint(Graphics g) { g.drawImage(canvasImage, 0, 0, null); }
}
