RotorRouter Applet
Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
hal@ups.physics.wisc.edu

A description of the algorithm can be found in the file index.html

Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

Instructions:  

	Run the program in a java-enabled browser by opening the file
	index.html.

	Or on a system with a Java SDK installed, enter:

		$ appletviewer index.html

	at the command line.

Version Information.
	v0.1 - Completed 2003-09-21 
		> All options are compiled in.
		> Proof of concept.

	v0.2 - Completed 2003-09-21 
		> Fixed a display bug. 
		> Show path of the last grain.
		> Slightly better look.

	Future Goals:
		- Switch to Swing (??)
		- Better Layout.
		- Pause Button.
		- Speed Control.
		- Restart Button.
		- Fix centering. 
		- Possible port to Java Swing.
