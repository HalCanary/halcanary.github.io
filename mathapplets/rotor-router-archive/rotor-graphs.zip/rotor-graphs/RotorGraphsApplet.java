/*
    Rotor Graphs Applet
    Copyright (C) 2001-2004 Hal Canary, Univerity of Wisconsin-Madison 
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
import java.io.*;
import java.net.*;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import java.applet.Applet;

/**
 * Note:  I need to put in better comments.
 **/
public class RotorGraphsApplet extends Applet implements ActionListener, 
							 Runnable {
    static final int canvasWidth = 950;
    static final int canvasHeight = 400;

    ICanvas canvas;
    Button button;             
    MathSystem graph;          // The MathSystem we are playing with
    FiniteGraphA graphA;
    FiniteGraphB graphB;
    FiniteGraphC graphC;
    OneDeeWalk graphD;
    OneDeeAgg graphE;
    Panel bPanel;
    Choice choice;
    Button pauseB;
    Choice skipEachC;
    InfoFrame infoFrame;
    Button infoButton;
    
    ///thread vars
    Thread t;
    boolean dead;
    boolean pause;
    int skipEach ;
    int sleep ;

    //static String graphAdesc = "Graph A: Walk on 4 vertices";
    //static String graphBdesc = "Graph B: Walk on 4 vertices";
    //static String graphCdesc = "Graph C: Walk on 12 vertices";
    static String graphAdesc = "Walk on finite graph A";
    static String graphBdesc = "Walk on finite graph B";
    static String graphCdesc = "Walk on finite graph C";
    static String graphDdesc = "1-D Walk";
    static String graphEdesc = "1-D Aggregation";

    public void init() {
	this.removeAll();
	this.setBackground(new Color(230,230,230));
	setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 

        // Set up our Buttons.
	bPanel = new Panel();
	bPanel.setBackground(new Color(230,230,230));
	bPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0)); 

        button = new Button( "Step");
	button.addActionListener(this);
        bPanel.add(button);
        button = new Button( "Stage");
	button.addActionListener(this);
        bPanel.add(button);
        button = new Button( "Reset");
	button.addActionListener(this);
        bPanel.add(button);

	choice = new Choice();
	choice.addItem(graphDdesc);
	choice.addItem(graphEdesc);
	choice.addItem(graphAdesc);
	choice.addItem(graphBdesc);
	choice.addItem(graphCdesc);
	choice.select(graphEdesc);
        bPanel.add(choice);

        pauseB = new Button("Paused (Press to Resume)");
	pauseB.addActionListener(this);
        bPanel.add(pauseB);

	skipEachC = new Choice();
	skipEachC.addItem("1 Step"    );
	skipEachC.addItem("1 Stage"   );
	skipEachC.addItem("10 Stages" );
	skipEachC.addItem("100 Stages");

	bPanel.add(new Label("Skip Each:"));
	bPanel.add(skipEachC);
	//skipEachC;

	infoButton = new Button("Info");
	infoButton.addActionListener(this);
	bPanel.add(infoButton);
	infoFrame = new InfoFrame("Info");

	add(bPanel);
	setVisible(true);

	canvas = new ICanvas(canvasWidth,canvasHeight,this);
	add(canvas);

	graphA = new FiniteGraphA() ;
	graphB = new FiniteGraphB() ;
	graphC = new FiniteGraphC() ;
	graphD = new OneDeeWalk() ;
	graphE = new OneDeeAgg() ;
	graph = graphE;
	drawCanvas();
	this.repaint();

	pause = true;
	skipEach = 0;
	sleep = 200;
	Thread t = new Thread(this);
	t.start();
    }

    public void start() { }
    public void stop() { }

    public void destroy() { 
	System.gc();
    }
 
    public void paint(Graphics g) {  }

    public void drawCanvas() {
	graph.draw(canvas.xSize,canvas.ySize,canvas.g);
	canvas.draw();
    }

    void pause() {
	pause = !pause;
	if (pause) 
	    pauseB.setLabel("Paused (Press to Resume)");
	else
	    pauseB.setLabel("Running (Press to Pause)");
	return;
    }
    public void step(int i) {
	graph.subiterate(i);
	infoFrame.changeText(graph.getInfo());
	drawCanvas();
    }
    public void stage(int i) {
	graph.iterate(i);
	infoFrame.changeText(graph.getInfo());
	drawCanvas();
	
    }

    public void actionPerformed(ActionEvent e) {
	if (e.getActionCommand() == "Step" ) { 
	    step(1);
	} else if (e.getActionCommand() == "Stage" ) { 
	    stage(1);
	} else if (e.getActionCommand() == "Reset" ) { 
	    if (choice.getSelectedItem() == graphAdesc)
		graph = graphA;
	    else if (choice.getSelectedItem() == graphBdesc)
		graph = graphB;
	    else if (choice.getSelectedItem() == graphCdesc)
		graph = graphC;
	    else if (choice.getSelectedItem() == graphDdesc)
		graph = graphD;
	    else if (choice.getSelectedItem() == graphEdesc)
		graph = graphE;
	    graph.reset();
	    drawCanvas();
	    //Running (Press to Pause);
	    //Paused (Press to Resume);
	} else if (e.getActionCommand() == "Paused (Press to Resume)" ) { 
	    pause();
	} else if (e.getActionCommand() == "Running (Press to Pause)" ) {
	    pause();
	} else if (e.getActionCommand() == "Info" ){
	    infoFrame.alert(graph.getInfo());
	}
    }
    /** when you make a thread**/
    public void run() {
 	while (!dead) {
	    if (!pause){
		if (skipEachC.getSelectedItem() == "1 Step")
		    step(1);
		else if (skipEachC.getSelectedItem() == "1 Stage")
		    stage(1);
		else if (skipEachC.getSelectedItem() == "10 Stages")
		    stage(10);
		else if (skipEachC.getSelectedItem() == "100 Stages")
		    stage(100);
	    }
	    try { 
		t.sleep(sleep); //miliseconds;
	    } catch (InterruptedException e) { }
	}
    }
}

class ICanvas extends Canvas {
    public ICanvas(int x, int y,Applet owner){
	super();
	xSize = x;
        ySize = y;
        i = owner.createImage(x,y);
	if (i == null) {
	    System.out.println("image is null!");
	} else 
	    g = i.getGraphics();
	this.setSize(xSize,ySize);
        graph = this.getGraphics();
    }
    public int xSize,ySize;
    public Image i; //image
    public Graphics g; //graphics of image
    public Graphics graph; //grpahics of this.
    public Dimension getPreferredSize() {
        return new Dimension(xSize,ySize);
    }
    public void draw() {
        if (i != null) {
	    if (graph == null)
		graph = this.getGraphics();
	    graph.drawImage(i,0,0,null);
        }
    }
    //public void update(Graphics g) { }
    public void paint(Graphics gr) { 
	gr.drawImage(i,0,0,null);
    }
}
