/* 
    2D Walk Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/
import java.awt.*;

/** Mathematical Model of the Pi Computer Object **/
public class TwoDeeWalk extends MathSystem{
    public static int MAX_SIZE = 1024;
    //public boolean allArrows;
    public boolean repaintme;
    public int aSize;
    char [] [] sandpile ;
    int middle;
    int posR;
    int posC;
    char lastDir;
    
    //public int [] recentR ;
    //public int [] recentC ;

    public boolean badness;
    public int subiteration;

    public boolean moved;

    public boolean lastSource;

    public int numSource;
    public int numDrain;

    boolean filled;
    boolean done;

    Color up;
    Color down;
    Color right;
    Color left;

    /** Current animation position  **/
    public double animate; 
	
    /** Current Iteration Number  **/
    public int n; 
    /**
     * The Constructor
     **/ 
    public TwoDeeWalk() {
	reset();
    }
    /** Restarts the system **/
    //    public abstract void reset();
    public void reset() {
	moved=true;
	lastSource = true;
	//allArrows = true;
	n = 0;
	numSource =0;
	numDrain = 0;
	animate=1;
	repaintme = true;
	badness = false;
	done = false;
	subiteration = 0;
	filled = false;
	aSize = 8;
	middle = aSize/2;
	blank(aSize,sandpile);
	posR = aSize/2;
	posC = aSize/2 - 1;
	//recentC = new int [aSize] ;
	//recentR = new int [aSize] ;
	up     = new Color(255,63,63); 
	down   = Color.green;
	right  = new Color(127,127,255); 
	left   = Color.yellow;
    }
    public void blank(int blanksize, char[][] pile) {
	sandpile = new char [blanksize][blanksize];
	for(int r = 0 ; r < blanksize ; r++) {
	    for(int c = 0 ; c < blanksize ; c++) {
		if ((r >= c) && (r+c < blanksize-1)) {
		    sandpile[r][c] = 'u' ;
		} else if ((r < c) && (r+c < blanksize)) {
		    sandpile[r][c] = 'r' ;
		} else if ((r <= c) && (r+c >= blanksize)) {
		    sandpile[r][c] = 'd' ;
		} else if ((r > c) && (r+c >= blanksize-1)) {
		    sandpile[r][c] = 'l' ;
		} else {
		    //shouldn't happen;
		    System.err.println("Othercase 1");
		    sandpile[r][c] = 'B' ;
		}
	    }
	}
	sandpile[(blanksize/2)-1][blanksize/2] = 'h';
    }

    public void iterate(int number) {
	for(int num = 0; (num < number) && (!filled); num++) {
	    iterate();
	} 
	return;
    }
    private void iterate() {
	if (done) {
	    n++;
	    moved=true;
	    subiteration = 0;
	    posR = aSize/2;
	    posC = aSize/2 - 1;
	    done = false;
	}
	while ((! done) && (! badness) && (! filled)) {
	    subiterate(1); 
	}
    }
    /** Does a subiteration, if applicable. **/
    public void subiterate(int subiterations) { 
	if (done) { // new iteration
	    n++;
	    moved = true;
	    subiteration = 0;
	    posR = aSize/2;
	    posC = aSize/2 - 1;
	    done = false;
	}
	else if (moved) {
	    //recentR [subiteration] = posR;
	    //recentC [subiteration] = posC;
	    subiteration++;
// 	    if (subiteration == recentR.length) {
// 		int oldsize = recentR.length;
// 		int tempR [] = recentR;
// 		int tempC [] = recentC;
// 		recentC = new int [oldsize * 2] ;
// 		recentR = new int [oldsize * 2] ;
// 		for(int i = 0; i < oldsize; i++) {
// 		    recentR [i] = tempR [i];
// 		    recentC [i] = tempC [i];
// 		}
// 	    }
	    char dir = sandpile[posR][posC];
	    // ROTATE the CELL.
	    if (dir == 'u') {
		sandpile[posR][posC] = 'r';
		lastDir = sandpile[posR][posC];
	    } else if (dir == 'r') {
		sandpile[posR][posC] = 'd';
		lastDir = sandpile[posR][posC];
	    } else if (dir == 'd') {
		sandpile[posR][posC] = 'l';
		lastDir = sandpile[posR][posC];
	    } else if (dir == 'l') {
		sandpile[posR][posC] = 'u';
		lastDir = sandpile[posR][posC];
	    } else {
		System.out.println("shouldn't happen! ");	
	    }
	    moved = false;
	} else {
	    char dir = sandpile[posR][posC];
	    if (dir == 'u') {
		posR--;	if (posR < 0) { filled = !resizeArray(); }
	    } else if (dir == 'r') {
		posC++;	if (posC == aSize) { filled = !resizeArray(); } 
	    } else if (dir == 'd') {
		posR++;	if (posR == aSize) { filled = !resizeArray(); }
	    } else if (dir == 'l') {
		posC--;	if (posC < 0) { filled = !resizeArray(); }
	    } else {
		System.out.println("shouldn't happen! ");	
	    }
	    moved = true;
	    if (sandpile[posR][posC] == 'h') {
		numDrain++;
		//recentR [subiteration] = -1;  // This indicates that 
		//recentC [subiteration] = -1;  //     we are done! 
		lastSource = false;
		done = true;
	    } else if (posR == aSize/2 && posC == (aSize/2)-1 
		       && subiteration > 1) {
		numSource++;
		lastSource = true;
		//recentR [subiteration] = -1;  // This indicates that 
		//recentC [subiteration] = -1;  //     we are done! 
		done = true;
	    } 
	}
	return ;
    }

    /** return true if successfull. **/
    private boolean resizeArray() {
	//System.out.println("Resizing! \n");	
	repaintme = true;
        int newArraySize = aSize * 2;
	if (newArraySize > MAX_SIZE) {
	    //do something here to stop this!!!!
	    badness = true;
	    return false;
	}
	int newMiddle = aSize; //(newArraySize) / 2;  
	int shift = newMiddle - middle;
	char [] [] oldPile = sandpile;	
	blank(newArraySize,sandpile);
	//25% wasteful!  What to do? Worry about smething else!
        for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
                sandpile[r+shift][c+shift] = oldPile[r][c] ;
            }
        }
	oldPile = null;
	//garbage collect???
        middle = newMiddle;
	posR = posR + shift;
	posC = posC + shift;
	aSize = newArraySize;
	return true;
    }

    public void printArray() {
	System.out.print("Grain number ");
	System.out.println(n);
	for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
		System.out.print(sandpile[r][c]);
		System.out.print(' ');
	    }
	    System.out.print('\n');
	}
	System.out.print('\n');
    }


    //    drawBlock(r, c, block, dir, gb, 0, 0);
    public void drawBlock(int row, int col, int size, char dir, 
			  java.awt.Graphics gb, int offsetX, int offsetY) {
	int x = (size * col) + offsetX;
	int y = (size * row) + offsetY;
	int cX = x + (size / 2); //center of square
	int cY = y + (size / 2);
	
	if      (dir == 'u') { gb.setColor(up); 	}
	else if (dir == 'r') { gb.setColor(right);	}
	else if (dir == 'd') { gb.setColor(down);	}
	else if (dir == 'l') { gb.setColor(left);	}
	else if (dir == 'h') { gb.setColor(Color.black); }
	gb.fillRect(x,y,size,size);

	if (size >= 5) {
	    gb.setColor(Color.black);
	    if (dir == 'u' || dir =='d') {
		gb.drawLine(cX, cY-(size/4), cX, cY+(size/4));
		if (dir == 'u') {
		    gb.drawLine(cX, cY-(size/4), cX+(size/4), cY);
		    gb.drawLine(cX, cY-(size/4), cX-(size/4), cY);
		} else {
		    gb.drawLine(cX, cY+(size/4), cX+(size/4), cY);
		    gb.drawLine(cX, cY+(size/4), cX-(size/4), cY);
		}
	    } else if (dir == 'r' || dir =='l') {
		gb.drawLine(cX-(size/4), cY, cX+(size/4), cY);
		if (dir == 'r') {
		    gb.drawLine(cX+(size/4), cY, cX, cY+(size/4));
		    gb.drawLine(cX+(size/4), cY, cX, cY-(size/4));
		} else {
		    gb.drawLine(cX-(size/4), cY, cX, cY+(size/4));
		    gb.drawLine(cX-(size/4), cY, cX, cY-(size/4));
		}
	    } 
	}
	return ;
    }

    /**
     * draw() 
     *
     * Draws itself on the graphics buffer.
     *
     * @param sizeX is the x size of region on which to draw.
     * @param sizeY is the y size of region on which to draw.
     **/ 
    public void draw(int sizeX, int sizeY, java.awt.Graphics gb){
	//public void draw(Graphics g,int x,int y) {
	int square; //size of thing to draw on.
	if (sizeX < sizeY) { square = sizeX; }
	else { square = sizeY; }
	int block = square / aSize;
	if (block < 1) { block=1; }
	gb.clearRect(0,0,sizeX,sizeY) ;
	//draw white square
	gb.setColor(Color.white);
	gb.fillRect(0,0,aSize * block,aSize * block) ;
	//draw black rectange
	//gb.setColor(Color.black);
	//gb.drawRect(0,0,(aSize * block)+1,(aSize * block)+1) ;
	//	draw colors and arrows.
	for (int r = 0 ; r < aSize ; r++) {
	    for (int c = 0 ; c < aSize ; c++) {
		char dir = sandpile[r][c];
		if (dir == 'u' || dir == 'r' || dir == 'd' || dir == 'l') {
		    drawBlock(r, c, block, dir, gb, 0, 0);
		} else if (sandpile[r][c] == 'h') {
		    //is the sink.  has no rotor.  is black hole.
		    gb.setColor(Color.black);
		    gb.fillRect((block * c), (block * r), block, block);
		}
	    }
	}
	if (block >= 5) {
	    //label the Source
	    gb.setColor(Color.white);
	    gb.drawRect((block*(aSize/2-1)),(block*aSize/2),
			block-1,block-1);
	    if (block >= 7) {
		gb.drawRect((block*(aSize/2-1))+1,(block*aSize/2)+1,
			    block-3,block-3);
		if (block >= 9) {
		    gb.drawRect((block*(aSize/2-1))+2,(block*aSize/2)+2,
				block-5,block-5);
		}
	    }
	    if (this.animate == 1.0 || (!moved) ) {
		//lable current thing position 
		drawBug(posR, posC, block, gb, 0, 0);
	    } else if (subiteration==0) {
		drawBug(posR, posC, block, gb, 1, 1);
	    } else {
		//char dir = sandpile[posR][posC];
		//if (dir == 'u' || dir == 'r' || dir == 'd' || dir == 'l') {
		    //first undraw posR,posC
		    //if (dir == 'u')
		    //drawBlock(posR, posC, block, 'l', gb, 0, 0);
		    //if (dir == 'r')
		    //drawBlock(posR, posC, block, 'u', gb, 0, 0);
		    //if (dir == 'd')
		    //drawBlock(posR, posC, block, 'r', gb, 0, 0);
		    //if (dir == 'l')
		    //drawBlock(posR, posC, block, 'd', gb, 0, 0);
		//}
		//then draw floating block
		int offset = (int) ((1.0-animate) * block);
		if (lastDir == 'u')
		    drawBug(posR, posC, block, gb, 0, offset);
		if (lastDir == 'r')
		    drawBug(posR, posC, block, gb, -1*offset, 0);
		if (lastDir == 'd')
		    drawBug(posR, posC, block, gb, 0, -1*offset);
		if (lastDir == 'l')
		    drawBug(posR, posC, block, gb, offset, 0);
	    }
	}
	if (sizeY > sizeX) {
	}
	return;
    }
    void drawBug(int row, int col, int size, Graphics gb, 
		 int xOffset, int yOffset) {
	gb.setColor(Color.black);
	gb.drawRect(((size*col)+1) + xOffset,(size*row)+1+ yOffset,
		    size-1,size-1);
	if (size > 6) { 
	    gb.setColor(Color.white);
	    gb.drawRect((size*col)+2+ xOffset,(size*row)+2+ yOffset,
			size-3,size-3);
	    if (size > 9) { 
		gb.setColor(Color.black);
		gb.drawRect((size*col)+3+ xOffset,(size*row)+3+ yOffset,
			    size-5,size-5);
	    }
	}
	return ;
    }
    public String getInfo() { return ""; }
}
