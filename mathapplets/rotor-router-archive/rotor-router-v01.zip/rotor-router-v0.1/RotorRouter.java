/* 
    RotorRouter Applet
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    A description of the algorithm can be found in the file index.html

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.
*/
import java.awt.*;

/** **/
public class RotorRouter {
    public int maxSize ;
    public int aSize;
    char [] [] sandpile ;
    int middleR;
    int middleC;
    int posR = middleR;
    int posC = middleC;
    
    public int iteration;

    public boolean badness;

    /** Creates a new empty RotorRouter **/
    public RotorRouter(int n) {
	maxSize = n;
	iteration = 0;
	badness = false;
	aSize = 9;
	sandpile = new char [aSize][aSize];
	for(int r = 0 ; r < aSize ; r++) {
	    for(int c = 0 ; c < aSize ; c++) {
		sandpile[r][c] = ' ' ;
	    }
	}
	middleR = 4;
	middleC = 4;
    } 

    public void iterate(int number) {
	for(int num = 0; num < number; num++) {
	    iteration++;
	    posR = middleR;
	    posC = middleC;
	    boolean done = false;
	    while ((! done) && (! badness)) {
		//System.out.println("start ");
		if (sandpile[posR][posC] == ' ') {
		    sandpile[posR][posC] = 'u';
		    done = true;
		} else if (sandpile[posR][posC] == 'u') {
		    sandpile[posR][posC] = 'r';
		    posR--;
		    if (posR < 0) { resizeArray(); }
		} else if (sandpile[posR][posC] == 'r') {
		    sandpile[posR][posC] = 'd';
		    //System.out.print("found r ");	
		    //System.out.println(posC);	
		    //System.out.println(aSize);	
		    posC++;
		    if (posC >= aSize) {
			resizeArray(); 
		    } else {
			//System.out.println("Bleg ");	
		    }
		} else if (sandpile[posR][posC] == 'd') {
		    sandpile[posR][posC] = 'l';
		    posR++;
		    if (posR >= aSize) { resizeArray(); }
		} else if (sandpile[posR][posC] == 'l') {
		    sandpile[posR][posC] = 'u';
		    posC--;
		    if (posC < 0) { resizeArray(); }
		} else {
		    //done = false ;
		    System.out.println("shouldn't happen! ");	
		    //System.out.println(sandpile[posR][posC]);	
		    //System.out.println(posR);
		    //System.out.println(posC);	
		}		
	    }
	} 
    }
    private boolean resizeArray() {
	//System.out.println("Resizing! \n");	
        int newArraySize = aSize * 2;
	if (newArraySize > maxSize) {
	    //do something here to stop this!!!!
	    badness = true;
	    return false;
	}
	int shift =  aSize / 2;
	char [] [] oldPile = sandpile;	
        sandpile = new char[newArraySize][newArraySize];
        for(int r = 0 ; r < newArraySize ; r++) {
            for(int c = 0 ; c < newArraySize ; c++) {
                sandpile[r][c] = ' ';
            }
        }
	//25% wasteful!  What to do? Worry about smething else!
        for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
                sandpile[r+shift][c+shift] = oldPile[r][c] ;
            }
        }
	oldPile = null;
	//garbage collect???
        middleR = middleR + shift;
        middleC = middleC + shift;
	posR = posR + shift;
	posC = posC + shift;
	aSize = newArraySize;
	return true;
    }

    public void printArray() {
	System.out.print("Grain number ");
	System.out.println(iteration);
	for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
		System.out.print(sandpile[r][c]);
		System.out.print(' ');
	    }
	    System.out.print('\n');
	}
	System.out.print('\n');
    }

    public void draw(Graphics g) {
	int block = maxSize / aSize;
	//g.setBackground(Color.white);
	g.clearRect(0,0,maxSize,maxSize) ;
        for(int r = 0 ; r < aSize-1 ; r++) {
            for(int c = 0 ; c < aSize-1 ; c++) {
		if (sandpile[r][c] == 'u') {
		    g.setColor(Color.yellow);
		    g.fillRect(block * c, block*r, block,block);
		} else if (sandpile[r][c] == 'r') {
		    g.setColor(Color.green);
		    g.fillRect(block * c, block*r, block,block);
		} else if (sandpile[r][c] == 'd') {
		    g.setColor(Color.blue);
		    g.fillRect(block * c, block*r, block,block);
		} else if (sandpile[r][c] == 'l') {
		    g.setColor(Color.red);
		    g.fillRect(block * c, block*r, block,block);
		} 
	    }
	}	
    }
    public static void main(String[] args) {
	RotorRouter r;
	r = new RotorRouter(550) ;
	r.iterate(900);
	while (! r.badness) {
	    r.printArray();
	    try { 
		Thread.sleep(500);  //miliseconds;
	    } catch (InterruptedException e) { }
	    r.iterate(1);
	}
    }
}
