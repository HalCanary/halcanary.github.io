PiCalculator Applet
Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
hal@ups.physics.wisc.edu

A description of the algorithm can be found in the file index.html

Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

Instructions:  

	Run the program in a java-enabled browser by opening the file
	index.html.

	Or on a system with a Java SDK installed, enter:

		$ appletviewer index.html

	at the command line.

Version Information.
	This program is a derivitive of my RotorRouter Applet.

	v01 - In Progrerss.
		> Turn RotorRoutrer into a Pi-Calculator.


