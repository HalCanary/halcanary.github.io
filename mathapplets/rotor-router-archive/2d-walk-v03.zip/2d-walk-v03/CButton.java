/*
    Java Bits - Usefull Java Classes
    Copyright (C) 2003  Hal Canary, Univerity of Wisconsin-Madison
    hal@ups.physics.wisc.edu

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/

import java.awt.*;
import java.awt.event.*;

/** Custom Button  Can be positioned at will on top of a component. **/
public class CButton {
    /** Coordinates and Size of this button. **/
    public Rectangle coords;
    /** **/
    public String text;
    /** does this button hava a border? **/
    public boolean border;
    private Font font;
    private FontMetrics metric;
    private int drop;
    private int ascent;
    Color lightGray;
    /** 
	Constructor.  
	@param s is the text
	@param x is the x coord of top left corner.
	@param y is the y coord of top left corner.
	@param b is the border.
	@param m is the fontmetrics for the text.
     **/
    public CButton(String s, int x, int y, boolean b, FontMetrics m) {
	this.border = b;
	this.text = new String(s); //make a copy of s, not a pointer to.
	this.metric = m;
	int width = metric.stringWidth(this.text + 15);
	this.drop = metric.getMaxDescent();
	this.ascent = metric.getMaxAscent();
	int height = drop + ascent + 10;
	this.coords = new Rectangle(x,y,width,height);
	lightGray = new Color(242,242,242);
	return;
    }
    /** 
	Change text of button and recalculate size.
	@param s is the new text.
	Since this rectange is going to change size, Don't forget to 
	wipe it if you have to--before it changes size.
     **/
    public void changeText(String s) {
	this.text = new String(s); //make a copy of s, not a pointer to.
	this.coords.width = this.metric.stringWidth(this.text + 15);
	//shouldn't change.
	//this.coords.height = this.drop + this.ascent + 10; 
	return;
    }
    /** 
	draw the string.
 	@param g is the graphics device onto which I should draw it.
     **/
    public void draw(Graphics g){
	//FIXME
	if (border) {
	    g.setColor(lightGray);
	    g.fillRect(this.coords.x, this.coords.y, 
		       this.coords.width, this.coords.height);
	    g.setColor(Color.black);
	    g.drawRect(this.coords.x, this.coords.y, 
		       this.coords.width, this.coords.height);
	}
	g.setColor(Color.black);
	g.drawString(this.text, this.coords.x + 5, 
		     this.coords.y + 5 + this.ascent);
	return;
    }
    /** 
	Draws a colored rectangel over the button. Do this before   
	a changeText().
	@param g is the graphics device onto which I should draw it.
	@param c is the background color.  If null, c is background color
     **/
    public void wipe(Graphics g, Color c){
	if (c == null) {
	    g.clearRect(this.coords.x, this.coords.y, 
			this.coords.width+15, this.coords.height+1);
	} else {
	    g.setColor(c);
	    g.fillRect(this.coords.x, this.coords.y, 
		       this.coords.width+15, this.coords.height+1);
	}
	return;
    }
    /** 
	@param e the mouse event.
     **/
    public boolean clicked(MouseEvent e){
	if (this.coords.contains(e.getPoint())) {
	    return true;
	} else {
	    return false;
	}
    }
}
