
		      Rotor Router Model Applet

   A description of the algorithm can be found in the file index.html.

   This work is copyright (C) 2003-2004 Hal Canary, University of
   Wisconsin-Madison.

   This work was supported by the University of Wisconsin.

   This work comes with ABSOLUTELY NO WARRANTY. This program is free
   software; you can redistribute it and/or modify it under the terms
   of version 2 of the GNU General Public License.  A copy of the
   liscence was distributed in the file LICENCE.txt

   To compile this software on a unix system, 
 	$ cd /(this directory)/src/
	$ make
