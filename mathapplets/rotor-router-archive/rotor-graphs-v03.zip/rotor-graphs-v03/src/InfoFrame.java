/*
    InfoFrame Class
    Part of JavaBits (Usefull Java Classes)
    Copyright (C) 2001-2003 Hal Canary, Univerity of Wisconsin-Madison 
    hal@ups.physics.wisc.edu

    Licence Information:

	This program is free software; you can redistribute it and/or
	modify it under the terms of version 2 of the GNU General
	Public License as published by the Free Software Foundation.

	A copy of the liscence was distributed in the file LICENCE.txt

	This program is distributed in the hope that it will be
	useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
	PURPOSE.  See the GNU General Public License for more details.

    See the README.txt file for version information,
*/

import java.awt.Graphics;
import java.awt.Color;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;

/**
 * This class reperesents a frame that pops up with information!
 **/
public class InfoFrame extends Frame implements ActionListener,WindowListener {
    public InfoFrame() {
	super("InfoFrame");
	create();
    }
    public InfoFrame(String tit) {
	super(tit);
	create();
    }
    TextArea ta;
    Button okayButton;
    Panel p;
    void create() {
	this.addWindowListener(this);
	p = new Panel();
	ta = new TextArea(20,80);
	ta.setEditable(false);
	ta.setText("Hello");
	p.add(ta);
	okayButton = new Button("Okay");
	okayButton.addActionListener(this);
	p.add(okayButton);
	this.add(p);
	setVisible(false);
    }
    
    void alert(String s) {
	ta.setText(s);
	pack();
	setVisible(true);
	this.show();
    }
    void changeText(String s) {
	ta.setText(s);
    }
    public void actionPerformed(ActionEvent e) {
	if (e.getActionCommand() == "Okay" ) { 
	    setVisible(false);
	}
    }
    public void windowClosed(WindowEvent e) { setVisible(false); }
    public void windowActivated(WindowEvent e) { }
    public void windowClosing(WindowEvent e) { setVisible(false); }
    public void windowDeactivated(WindowEvent e) { }
    public void windowDeiconified(WindowEvent e) { }
    public void windowIconified(WindowEvent e) { }
    public void windowOpened(WindowEvent e) { }
}
